# To-Do List Mahasiswa + Toko Mahasiswa (Spring Boot + ORM)

Aplikasi web untuk mencatat tugas kuliah **dan** menjalankan usaha kecil (jualan) mahasiswa.
Versi ini melanjutkan praktikum sebelumnya dengan menerapkan materi **Pertemuan 4 – ORM (Object Relational Mapping)**:
data tidak lagi *dummy in-memory*, tetapi disimpan di **MySQL** melalui **Spring Data JPA + Hibernate**.

## Ringkasan

| Item | Keterangan |
|---|---|
| Backend | Java 17, Spring Boot 3.2.5, Spring MVC |
| ORM | Spring Data JPA, **Hibernate** sebagai JPA provider |
| Database | MySQL 8 (test memakai H2 in-memory) |
| View | Thymeleaf, Bootstrap 5.3, Bootstrap Icons |
| Arsitektur | MVC berlapis: Controller → Service → Repository → Entity |

## Penerapan Materi ORM

Materi menjelaskan ORM sebagai penjembatan *paradigma berorientasi objek* dan *basis data relasional*, sehingga
kode tidak bergantung pada dialek SQL. Pemetaannya di proyek ini:

| Konsep di materi | Implementasi |
|---|---|
| Tanpa ORM: `SELECT * FROM persons;` | Dengan ORM: `tugasRepository.findAll()` |
| `SELECT * FROM persons WHERE id = 1;` | `tugasRepository.findById(1L)` |
| Pemetaan class Java → tabel | `@Entity`, `@Table`, `@Column` pada paket `model` |
| Pemetaan tipe data Java → tipe SQL | `LocalDate`→`DATE`, `BigDecimal`→`DECIMAL`, `enum`→kolom status, dst. |
| Relasi antar objek → foreign key | `@ManyToOne` / `@OneToMany` (lihat ERD) |
| ORM berperan di lapisan Model (MVC) | Entity + Repository berada di lapisan model |
| Mengurangi kerja manual SQL/JDBC | `JpaRepository` memberi CRUD otomatis; query khusus lewat JPQL/derived query |
| Independen dari produk RDBMS | Tidak ada SQL mentah; test berjalan di H2, produksi di MySQL |

Teknik ORM lain yang dipakai: *derived query* (`countByStatus`), JPQL dengan `JOIN FETCH` (hindari N+1),
agregasi dengan *constructor expression* (produk terlaris), `Pageable`, *pessimistic lock* untuk stok,
dan *dirty checking* (entity yang berubah di dalam transaksi otomatis di-`UPDATE`).

## Database

Nama database: `db_todolist_mahasiswa` — skrip ada di folder `database/`:

- `database/schema.sql` — membuat database + 7 tabel (sama dengan hasil pemetaan entity).
- `database/seed.sql` — data contoh (opsional; aplikasi juga mengisi data contoh sendiri lewat `DataSeeder`).

### ERD

```mermaid
erDiagram
    MATA_KULIAH ||--o{ TUGAS : "memiliki"
    KATEGORI    ||--o{ PRODUK : "mengelompokkan"
    PELANGGAN   ||--o{ PESANAN : "membuat"
    PESANAN     ||--|{ ITEM_PESANAN : "berisi"
    PRODUK      ||--o{ ITEM_PESANAN : "dipesan sebagai"

    MATA_KULIAH { bigint id PK
                  varchar kode UK
                  varchar nama
                  int sks }
    TUGAS { bigint id PK
            varchar nama_tugas
            bigint mata_kuliah_id FK
            varchar deskripsi
            date deadline
            varchar prioritas
            varchar status }
    KATEGORI { bigint id PK
               varchar nama UK }
    PRODUK { bigint id PK
             varchar nama
             decimal harga
             int stok
             bit aktif
             bigint kategori_id FK }
    PELANGGAN { bigint id PK
                varchar nama
                varchar email
                varchar no_hp
                varchar alamat }
    PESANAN { bigint id PK
              varchar nomor_pesanan UK
              bigint pelanggan_id FK
              datetime tanggal_pesanan
              enum status
              decimal total_harga }
    ITEM_PESANAN { bigint id PK
                   bigint pesanan_id FK
                   bigint produk_id FK
                   int jumlah
                   decimal harga_satuan }
```

## Cara Menjalankan

### 1. Prasyarat
- JDK 17 atau lebih baru
- MySQL 8 yang sedang berjalan di `localhost:3306`

### 2. Siapkan database
Pilih salah satu:
- **Otomatis (disarankan):** tidak perlu melakukan apa pun. URL koneksi memakai `createDatabaseIfNotExist=true`,
  Hibernate membuat tabel (`ddl-auto=update`), dan `DataSeeder` mengisi data contoh saat tabel masih kosong.
- **Manual:** `mysql -u root -p < database/schema.sql` (lalu opsional `database/seed.sql`).

### 3. Atur kredensial (jika perlu)
Default: user `root`, password kosong. Ubah lewat environment variable:

```powershell
$env:DB_USERNAME="root"; $env:DB_PASSWORD="passwordAnda"
```

### 4. Jalankan
```powershell
.\mvnw.cmd spring-boot:run
```
Lalu buka http://localhost:8080. SQL hasil terjemahan ORM akan tampil di console (`spring.jpa.show-sql=true`).

### 5. Menjalankan test
```powershell
.\mvnw.cmd test
```
Test memakai profil `test` (H2 in-memory), jadi **tidak membutuhkan MySQL**.

## Fitur

### Modul Tugas (sekarang tersimpan di database)
- Tambah, **ubah**, hapus, dan tandai selesai (sebelumnya hanya simulasi UI).
- Validasi form (nama wajib, deadline wajib, dll.) dengan pesan galat per kolom.
- Mata kuliah kini entity tersendiri (relasi Many-to-One dengan Tugas).
- Dashboard, pencarian, filter, pengurutan, dan label "Terlambat" tetap berfungsi.

### Modul Toko Mahasiswa (fitur bisnis / jualan)
Mahasiswa dapat berjualan perlengkapan kuliah, template digital, dan aksesori.

| Halaman | URL | Fungsi |
|---|---|---|
| Dashboard Penjualan | `/toko` | Total pendapatan, jumlah pesanan terbayar, pesanan menunggu pembayaran, produk aktif, **produk terlaris**, **peringatan stok menipis**, pesanan terbaru |
| Produk | `/produk` | CRUD produk: kategori, harga, stok, aktif/nonaktif |
| Pelanggan | `/pelanggan` | CRUD pelanggan |
| Pesanan | `/pesanan` | Daftar pesanan + filter status, detail pesanan |
| Buat Pesanan | `/pesanan/baru` | Satu pesanan berisi banyak produk, estimasi total langsung dihitung |

**Aturan bisnis** (di `PesananService`, satu transaksi database):
- Stok divalidasi dan otomatis berkurang saat pesanan dibuat; jika salah satu produk kurang, seluruh pesanan dibatalkan (rollback).
- Harga disalin ke item pesanan, sehingga perubahan harga produk tidak mengubah riwayat transaksi.
- Baris produk yang sama digabung; total dihitung di server, bukan dipercaya dari browser.
- Alur status: `Menunggu Pembayaran → Dibayar → Dikirim → Selesai`; pembatalan hanya dari *Menunggu Pembayaran* atau *Dibayar* dan **mengembalikan stok**.
- Pendapatan di laporan hanya menghitung pesanan berstatus Dibayar, Dikirim, atau Selesai.
- Produk yang sudah pernah dipesan tidak dihapus permanen, hanya dinonaktifkan; pelanggan yang punya pesanan tidak bisa dihapus.
- Baris produk dikunci (`SELECT ... FOR UPDATE`) agar stok tidak terjual ganda saat ada pesanan bersamaan.

## Struktur Proyek

```text
.
├── database/
│   ├── schema.sql                  # DDL MySQL
│   └── seed.sql                    # Data contoh (opsional)
├── pom.xml
└── src/
    ├── main/java/com/mahasiswa/todolist/
    │   ├── TodolistMahasiswaApplication.java
    │   ├── config/DataSeeder.java            # Isi data contoh jika tabel kosong
    │   ├── controller/                       # Dashboard, Tugas, Toko, Produk, Pelanggan, Pesanan
    │   ├── dto/                              # ProdukTerlarisDto, RingkasanToko
    │   ├── exception/BisnisException.java
    │   ├── model/                            # Entity JPA + StatusPesanan (enum)
    │   ├── repository/                       # Interface JpaRepository
    │   └── service/                          # Logika bisnis & laporan
    ├── main/resources/
    │   ├── application.properties            # Konfigurasi MySQL + JPA
    │   ├── static/{css,js}
    │   └── templates/                        # fragments, tugas, toko, produk, pelanggan, pesanan
    └── test/
        ├── java/.../TodolistMahasiswaApplicationTests.java   # Modul tugas
        ├── java/.../TokoMahasiswaTests.java                  # Modul toko + aturan bisnis
        └── resources/application-test.properties             # H2 untuk test
```

## Gagasan Pengembangan Berikutnya
- Autentikasi (Spring Security) agar tiap mahasiswa punya toko dan tugas sendiri.
- Upload foto produk, ekspor laporan penjualan ke PDF/Excel.
- Paginasi dan pencarian di sisi server untuk data besar.
- Migrasi skema dengan Flyway menggantikan `ddl-auto=update`.
