package com.mahasiswa.todolist.repository;

import com.mahasiswa.todolist.dto.ProdukTerlarisDto;
import com.mahasiswa.todolist.model.ItemPesanan;
import com.mahasiswa.todolist.model.StatusPesanan;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface ItemPesananRepository extends JpaRepository<ItemPesanan, Long> {

    boolean existsByProdukId(Long produkId);

    /** Agregasi: total terjual & omzet per produk, hanya dari pesanan yang dihitung sebagai penjualan. */
    @Query("select new com.mahasiswa.todolist.dto.ProdukTerlarisDto(p.nama, sum(i.jumlah), sum(i.hargaSatuan * i.jumlah)) "
            + "from ItemPesanan i join i.produk p join i.pesanan o "
            + "where o.status in :statuses "
            + "group by p.id, p.nama "
            + "order by sum(i.jumlah) desc")
    List<ProdukTerlarisDto> findProdukTerlaris(@Param("statuses") Collection<StatusPesanan> statuses, Pageable pageable);
}
