package com.mahasiswa.todolist.service;

import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.ItemPesanan;
import com.mahasiswa.todolist.model.Pelanggan;
import com.mahasiswa.todolist.model.Pesanan;
import com.mahasiswa.todolist.model.Produk;
import com.mahasiswa.todolist.model.StatusPesanan;
import com.mahasiswa.todolist.repository.PelangganRepository;
import com.mahasiswa.todolist.repository.PesananRepository;
import com.mahasiswa.todolist.repository.ProdukRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

/**
 * Logika bisnis penjualan: membuat pesanan (validasi stok, kurangi stok, hitung total),
 * mengubah status, dan membatalkan pesanan (stok dikembalikan).
 */
@Service
@Transactional(readOnly = true)
public class PesananService {

    private final PesananRepository pesananRepository;
    private final PelangganRepository pelangganRepository;
    private final ProdukRepository produkRepository;

    public PesananService(PesananRepository pesananRepository,
                          PelangganRepository pelangganRepository,
                          ProdukRepository produkRepository) {
        this.pesananRepository = pesananRepository;
        this.pelangganRepository = pelangganRepository;
        this.produkRepository = produkRepository;
    }

    public List<Pesanan> getAll(StatusPesanan filterStatus) {
        if (filterStatus == null) {
            return pesananRepository.findAllWithPelanggan();
        }
        return pesananRepository.findByStatusWithPelanggan(filterStatus);
    }

    public Optional<Pesanan> findDetail(Long id) {
        return pesananRepository.findDetailById(id);
    }

    /**
     * Membuat pesanan baru. Seluruh proses berada dalam satu transaksi:
     * jika salah satu produk stoknya kurang, semua perubahan di-rollback.
     *
     * @param produkIds  daftar id produk (boleh ada elemen null = baris kosong di form)
     * @param jumlahList daftar jumlah, urutannya sejajar dengan produkIds
     */
    @Transactional
    public Pesanan buatPesanan(Long pelangganId, List<Long> produkIds, List<Integer> jumlahList, String catatan) {
        if (pelangganId == null) {
            throw new BisnisException("Pelanggan wajib dipilih.");
        }
        Pelanggan pelanggan = pelangganRepository.findById(pelangganId)
                .orElseThrow(() -> new BisnisException("Pelanggan tidak ditemukan."));

        // Gabungkan baris produk yang sama. TreeMap = urut id, supaya urutan penguncian baris konsisten.
        Map<Long, Integer> kebutuhan = new TreeMap<>();
        int jumlahBaris = produkIds == null ? 0 : produkIds.size();
        for (int i = 0; i < jumlahBaris; i++) {
            Long produkId = produkIds.get(i);
            if (produkId == null) {
                continue; // baris kosong
            }
            Integer jumlah = (jumlahList != null && i < jumlahList.size()) ? jumlahList.get(i) : null;
            if (jumlah == null || jumlah <= 0) {
                throw new BisnisException("Jumlah pembelian harus lebih dari 0.");
            }
            kebutuhan.merge(produkId, jumlah, Integer::sum);
        }
        if (kebutuhan.isEmpty()) {
            throw new BisnisException("Pilih minimal satu produk untuk dipesan.");
        }

        Pesanan pesanan = new Pesanan();
        pesanan.setPelanggan(pelanggan);
        pesanan.setTanggalPesanan(LocalDateTime.now());
        pesanan.setStatus(StatusPesanan.MENUNGGU_PEMBAYARAN);
        pesanan.setCatatan(catatan == null || catatan.isBlank() ? null : catatan.trim());
        pesanan.setNomorPesanan("TMP-" + System.nanoTime()); // diganti setelah id terbentuk

        for (Map.Entry<Long, Integer> e : kebutuhan.entrySet()) {
            Produk produk = produkRepository.findByIdForUpdate(e.getKey())
                    .orElseThrow(() -> new BisnisException("Produk tidak ditemukan."));
            if (!produk.isAktif()) {
                throw new BisnisException("Produk \"" + produk.getNama() + "\" sudah tidak dijual.");
            }
            if (produk.getStok() < e.getValue()) {
                throw new BisnisException("Stok \"" + produk.getNama() + "\" tidak cukup (tersisa "
                        + produk.getStok() + ", diminta " + e.getValue() + ").");
            }
            produk.setStok(produk.getStok() - e.getValue());
            pesanan.tambahItem(new ItemPesanan(produk, e.getValue()));
        }

        Pesanan tersimpan = pesananRepository.save(pesanan);
        tersimpan.setNomorPesanan("INV-"
                + tersimpan.getTanggalPesanan().format(DateTimeFormatter.ofPattern("yyyyMMdd"))
                + "-" + String.format("%05d", tersimpan.getId()));
        return tersimpan;
    }

    /** Ubah status pesanan mengikuti alur yang diizinkan; pembatalan mengembalikan stok. */
    @Transactional
    public void ubahStatus(Long id, StatusPesanan statusBaru) {
        Pesanan pesanan = pesananRepository.findDetailById(id)
                .orElseThrow(() -> new BisnisException("Pesanan tidak ditemukan."));
        if (!pesanan.getStatus().bolehBerubahKe(statusBaru)) {
            throw new BisnisException("Status tidak dapat diubah dari \"" + pesanan.getStatus().getLabel()
                    + "\" ke \"" + statusBaru.getLabel() + "\".");
        }
        if (statusBaru == StatusPesanan.DIBATALKAN) {
            for (ItemPesanan item : pesanan.getItems()) {
                Produk produk = produkRepository.findByIdForUpdate(item.getProduk().getId())
                        .orElseThrow(() -> new BisnisException("Produk tidak ditemukan."));
                produk.setStok(produk.getStok() + item.getJumlah());
            }
        }
        pesanan.setStatus(statusBaru);
    }
}
