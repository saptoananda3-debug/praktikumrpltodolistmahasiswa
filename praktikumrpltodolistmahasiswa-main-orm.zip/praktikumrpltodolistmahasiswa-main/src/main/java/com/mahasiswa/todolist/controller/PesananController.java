package com.mahasiswa.todolist.controller;

import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.Pesanan;
import com.mahasiswa.todolist.model.StatusPesanan;
import com.mahasiswa.todolist.service.PelangganService;
import com.mahasiswa.todolist.service.PesananService;
import com.mahasiswa.todolist.service.ProdukService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

/** Transaksi penjualan: daftar pesanan, buat pesanan, detail, dan perubahan status. */
@Controller
@RequestMapping("/pesanan")
public class PesananController {

    private final PesananService pesananService;
    private final PelangganService pelangganService;
    private final ProdukService produkService;

    public PesananController(PesananService pesananService,
                             PelangganService pelangganService,
                             ProdukService produkService) {
        this.pesananService = pesananService;
        this.pelangganService = pelangganService;
        this.produkService = produkService;
    }

    @GetMapping
    public String daftar(@RequestParam(required = false) String status, Model model) {
        StatusPesanan filter = parseStatus(status);
        model.addAttribute("activePage", "pesanan");
        model.addAttribute("pageTitle", "Daftar Pesanan");
        model.addAttribute("daftarPesanan", pesananService.getAll(filter));
        model.addAttribute("semuaStatus", StatusPesanan.values());
        model.addAttribute("filterStatus", filter);
        return "pesanan/index";
    }

    @GetMapping("/baru")
    public String formBaru(Model model) {
        model.addAttribute("activePage", "pesanan-baru");
        model.addAttribute("pageTitle", "Buat Pesanan Baru");
        model.addAttribute("pelangganList", pelangganService.getAll());
        model.addAttribute("produkList", produkService.getTersedia());
        return "pesanan/form";
    }

    @PostMapping("/simpan")
    public String simpan(@RequestParam(required = false) Long pelangganId,
                         @RequestParam(name = "produkId", required = false) List<Long> produkIds,
                         @RequestParam(name = "jumlah", required = false) List<Integer> jumlahList,
                         @RequestParam(required = false) String catatan,
                         RedirectAttributes redirect) {
        try {
            Pesanan pesanan = pesananService.buatPesanan(pelangganId, produkIds, jumlahList, catatan);
            redirect.addFlashAttribute("sukses", "Pesanan " + pesanan.getNomorPesanan() + " berhasil dibuat.");
            return "redirect:/pesanan/" + pesanan.getId();
        } catch (BisnisException e) {
            redirect.addFlashAttribute("galat", e.getMessage());
            return "redirect:/pesanan/baru";
        }
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model, RedirectAttributes redirect) {
        Optional<Pesanan> pesanan = pesananService.findDetail(id);
        if (pesanan.isEmpty()) {
            redirect.addFlashAttribute("galat", "Pesanan tidak ditemukan.");
            return "redirect:/pesanan";
        }
        model.addAttribute("activePage", "pesanan");
        model.addAttribute("pageTitle", "Detail Pesanan");
        model.addAttribute("pesanan", pesanan.get());
        return "pesanan/detail";
    }

    @PostMapping("/{id}/status")
    public String ubahStatus(@PathVariable Long id, @RequestParam String status, RedirectAttributes redirect) {
        try {
            StatusPesanan baru = StatusPesanan.valueOf(status);
            pesananService.ubahStatus(id, baru);
            redirect.addFlashAttribute("sukses", "Status pesanan diubah menjadi " + baru.getLabel() + ".");
        } catch (IllegalArgumentException e) {
            redirect.addFlashAttribute("galat", "Status tidak dikenal.");
        } catch (BisnisException e) {
            redirect.addFlashAttribute("galat", e.getMessage());
        }
        return "redirect:/pesanan/" + id;
    }

    private StatusPesanan parseStatus(String status) {
        if (status == null || status.isBlank()) {
            return null;
        }
        try {
            return StatusPesanan.valueOf(status);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
