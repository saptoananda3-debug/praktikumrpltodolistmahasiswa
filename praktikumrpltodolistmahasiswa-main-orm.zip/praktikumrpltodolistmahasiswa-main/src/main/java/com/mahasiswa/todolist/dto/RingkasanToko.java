package com.mahasiswa.todolist.dto;

import java.math.BigDecimal;

/** Angka ringkasan untuk dashboard penjualan. */
public class RingkasanToko {

    private final BigDecimal totalPendapatan;
    private final long jumlahPenjualan;
    private final long pesananMenunggu;
    private final long produkAktif;

    public RingkasanToko(BigDecimal totalPendapatan, long jumlahPenjualan, long pesananMenunggu, long produkAktif) {
        this.totalPendapatan = totalPendapatan;
        this.jumlahPenjualan = jumlahPenjualan;
        this.pesananMenunggu = pesananMenunggu;
        this.produkAktif = produkAktif;
    }

    public BigDecimal getTotalPendapatan() { return totalPendapatan; }
    public long getJumlahPenjualan() { return jumlahPenjualan; }
    public long getPesananMenunggu() { return pesananMenunggu; }
    public long getProdukAktif() { return produkAktif; }
}
