package com.mahasiswa.todolist.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** Pelanggan toko. One-to-Many ke Pesanan. */
@Entity
@Table(name = "pelanggan")
public class Pelanggan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nama pelanggan wajib diisi")
    @Size(max = 100, message = "Nama maksimal 100 karakter")
    @Column(nullable = false, length = 100)
    private String nama;

    @Email(message = "Format email tidak valid")
    @Size(max = 100, message = "Email maksimal 100 karakter")
    @Column(length = 100)
    private String email;

    @Size(max = 20, message = "No. HP maksimal 20 karakter")
    @Column(name = "no_hp", length = 20)
    private String noHp;

    @Size(max = 255, message = "Alamat maksimal 255 karakter")
    private String alamat;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @OneToMany(mappedBy = "pelanggan")
    private List<Pesanan> daftarPesanan = new ArrayList<>();

    public Pelanggan() {
    }

    public Pelanggan(String nama, String email, String noHp, String alamat) {
        this.nama = nama;
        this.email = email;
        this.noHp = noHp;
        this.alamat = alamat;
    }

    @PrePersist
    void prePersist() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getNoHp() { return noHp; }
    public void setNoHp(String noHp) { this.noHp = noHp; }

    public String getAlamat() { return alamat; }
    public void setAlamat(String alamat) { this.alamat = alamat; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public List<Pesanan> getDaftarPesanan() { return daftarPesanan; }
    public void setDaftarPesanan(List<Pesanan> daftarPesanan) { this.daftarPesanan = daftarPesanan; }
}
