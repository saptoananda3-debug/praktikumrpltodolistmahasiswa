package com.mahasiswa.todolist.service;

import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.Pelanggan;
import com.mahasiswa.todolist.repository.PelangganRepository;
import com.mahasiswa.todolist.repository.PesananRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class PelangganService {

    private final PelangganRepository pelangganRepository;
    private final PesananRepository pesananRepository;

    public PelangganService(PelangganRepository pelangganRepository, PesananRepository pesananRepository) {
        this.pelangganRepository = pelangganRepository;
        this.pesananRepository = pesananRepository;
    }

    public List<Pelanggan> getAll() {
        return pelangganRepository.findAllByOrderByNamaAsc();
    }

    public Optional<Pelanggan> findById(Long id) {
        return pelangganRepository.findById(id);
    }

    @Transactional
    public Pelanggan simpan(Pelanggan pelanggan) {
        // Email kosong disimpan sebagai NULL
        if (pelanggan.getEmail() != null && pelanggan.getEmail().isBlank()) {
            pelanggan.setEmail(null);
        }
        return pelangganRepository.save(pelanggan);
    }

    @Transactional
    public void hapus(Long id) {
        if (pesananRepository.existsByPelangganId(id)) {
            throw new BisnisException("Pelanggan tidak bisa dihapus karena sudah memiliki riwayat pesanan.");
        }
        if (!pelangganRepository.existsById(id)) {
            throw new BisnisException("Pelanggan tidak ditemukan.");
        }
        pelangganRepository.deleteById(id);
    }
}
