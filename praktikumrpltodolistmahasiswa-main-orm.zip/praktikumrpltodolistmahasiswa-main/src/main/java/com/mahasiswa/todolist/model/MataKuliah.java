package com.mahasiswa.todolist.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Entity Mata Kuliah.
 * Relasi ORM: satu MataKuliah memiliki banyak Tugas (One-to-Many).
 */
@Entity
@Table(name = "mata_kuliah")
public class MataKuliah {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 20)
    private String kode;

    @Column(nullable = false, length = 100)
    private String nama;

    @Column(nullable = false)
    private int sks;

    @OneToMany(mappedBy = "mataKuliah")
    private List<Tugas> daftarTugas = new ArrayList<>();

    public MataKuliah() {
    }

    public MataKuliah(String kode, String nama, int sks) {
        this.kode = kode;
        this.nama = nama;
        this.sks = sks;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getKode() { return kode; }
    public void setKode(String kode) { this.kode = kode; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public int getSks() { return sks; }
    public void setSks(int sks) { this.sks = sks; }

    public List<Tugas> getDaftarTugas() { return daftarTugas; }
    public void setDaftarTugas(List<Tugas> daftarTugas) { this.daftarTugas = daftarTugas; }
}
