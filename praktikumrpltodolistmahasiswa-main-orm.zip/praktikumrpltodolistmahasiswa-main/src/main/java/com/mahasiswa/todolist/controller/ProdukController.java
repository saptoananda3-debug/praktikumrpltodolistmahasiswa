package com.mahasiswa.todolist.controller;

import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.Produk;
import com.mahasiswa.todolist.service.KategoriService;
import com.mahasiswa.todolist.service.ProdukService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

/** Manajemen katalog produk Toko Mahasiswa. */
@Controller
@RequestMapping("/produk")
public class ProdukController {

    private final ProdukService produkService;
    private final KategoriService kategoriService;

    public ProdukController(ProdukService produkService, KategoriService kategoriService) {
        this.produkService = produkService;
        this.kategoriService = kategoriService;
    }

    @GetMapping
    public String daftar(Model model) {
        model.addAttribute("activePage", "produk");
        model.addAttribute("pageTitle", "Katalog Produk");
        model.addAttribute("daftarProduk", produkService.getAll());
        return "produk/index";
    }

    @GetMapping("/tambah")
    public String formTambah(Model model) {
        isiModelForm(model, new Produk(), null, false);
        return "produk/form";
    }

    @GetMapping("/{id}/edit")
    public String formEdit(@PathVariable Long id, Model model, RedirectAttributes redirect) {
        Optional<Produk> produk = produkService.findById(id);
        if (produk.isEmpty()) {
            redirect.addFlashAttribute("galat", "Produk tidak ditemukan.");
            return "redirect:/produk";
        }
        Long kategoriId = produk.get().getKategori() != null ? produk.get().getKategori().getId() : null;
        isiModelForm(model, produk.get(), kategoriId, true);
        return "produk/form";
    }

    @PostMapping("/simpan")
    public String simpan(@Valid @ModelAttribute("produk") Produk produk,
                         BindingResult binding,
                         @RequestParam(required = false) Long kategoriId,
                         Model model,
                         RedirectAttributes redirect) {
        if (kategoriId == null) {
            binding.addError(new FieldError("produk", "kategori", "Kategori wajib dipilih"));
        }
        if (binding.hasErrors()) {
            isiModelForm(model, produk, kategoriId, produk.getId() != null);
            return "produk/form";
        }
        boolean baru = produk.getId() == null;
        try {
            produkService.simpan(produk, kategoriId);
        } catch (BisnisException e) {
            redirect.addFlashAttribute("galat", e.getMessage());
            return "redirect:/produk";
        }
        redirect.addFlashAttribute("sukses", baru ? "Produk berhasil ditambahkan." : "Produk berhasil diperbarui.");
        return "redirect:/produk";
    }

    @PostMapping("/{id}/hapus")
    public String hapus(@PathVariable Long id, RedirectAttributes redirect) {
        try {
            boolean terhapus = produkService.hapusAtauNonaktifkan(id);
            redirect.addFlashAttribute("sukses", terhapus
                    ? "Produk berhasil dihapus."
                    : "Produk sudah pernah dipesan, jadi hanya dinonaktifkan (riwayat pesanan tetap aman).");
        } catch (BisnisException e) {
            redirect.addFlashAttribute("galat", e.getMessage());
        }
        return "redirect:/produk";
    }

    private void isiModelForm(Model model, Produk produk, Long kategoriId, boolean edit) {
        model.addAttribute("activePage", "produk");
        model.addAttribute("pageTitle", edit ? "Ubah Produk" : "Tambah Produk");
        model.addAttribute("produk", produk);
        model.addAttribute("kategoriList", kategoriService.getAll());
        model.addAttribute("selectedKategoriId", kategoriId);
        model.addAttribute("modeEdit", edit);
    }
}
