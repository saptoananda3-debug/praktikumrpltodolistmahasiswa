package com.mahasiswa.todolist.repository;

import com.mahasiswa.todolist.model.Produk;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ProdukRepository extends JpaRepository<Produk, Long> {

    @Query("select p from Produk p left join fetch p.kategori order by p.nama asc")
    List<Produk> findAllWithKategori();

    /** Produk yang boleh dipesan: aktif dan stok tersedia. */
    @Query("select p from Produk p left join fetch p.kategori where p.aktif = true and p.stok > 0 order by p.nama asc")
    List<Produk> findTersedia();

    /** Mengunci baris produk (SELECT ... FOR UPDATE) agar stok tidak terjual ganda saat ada pesanan bersamaan. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from Produk p where p.id = :id")
    Optional<Produk> findByIdForUpdate(@Param("id") Long id);

    List<Produk> findByAktifTrueAndStokLessThanEqualOrderByStokAsc(Integer batas);

    long countByAktifTrue();
}
