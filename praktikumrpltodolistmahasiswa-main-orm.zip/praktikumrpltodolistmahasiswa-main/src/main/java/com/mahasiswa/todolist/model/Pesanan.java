package com.mahasiswa.todolist.model;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Header pesanan (transaksi penjualan).
 * Pelanggan 1 --- N Pesanan 1 --- N ItemPesanan N --- 1 Produk
 */
@Entity
@Table(name = "pesanan")
public class Pesanan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nomor_pesanan", nullable = false, unique = true, length = 40)
    private String nomorPesanan;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "pelanggan_id", nullable = false)
    private Pelanggan pelanggan;

    @Column(name = "tanggal_pesanan", nullable = false)
    private LocalDateTime tanggalPesanan;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private StatusPesanan status = StatusPesanan.MENUNGGU_PEMBAYARAN;

    @Column(length = 255)
    private String catatan;

    @Column(name = "total_harga", nullable = false, precision = 14, scale = 2)
    private BigDecimal totalHarga = BigDecimal.ZERO;

    @OneToMany(mappedBy = "pesanan", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ItemPesanan> items = new ArrayList<>();

    public Pesanan() {
    }

    public void tambahItem(ItemPesanan item) {
        item.setPesanan(this);
        items.add(item);
        hitungTotal();
    }

    public void hitungTotal() {
        BigDecimal total = BigDecimal.ZERO;
        for (ItemPesanan item : items) {
            total = total.add(item.getSubtotal());
        }
        this.totalHarga = total;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNomorPesanan() { return nomorPesanan; }
    public void setNomorPesanan(String nomorPesanan) { this.nomorPesanan = nomorPesanan; }

    public Pelanggan getPelanggan() { return pelanggan; }
    public void setPelanggan(Pelanggan pelanggan) { this.pelanggan = pelanggan; }

    public LocalDateTime getTanggalPesanan() { return tanggalPesanan; }
    public void setTanggalPesanan(LocalDateTime tanggalPesanan) { this.tanggalPesanan = tanggalPesanan; }

    public StatusPesanan getStatus() { return status; }
    public void setStatus(StatusPesanan status) { this.status = status; }

    public String getCatatan() { return catatan; }
    public void setCatatan(String catatan) { this.catatan = catatan; }

    public BigDecimal getTotalHarga() { return totalHarga; }
    public void setTotalHarga(BigDecimal totalHarga) { this.totalHarga = totalHarga; }

    public List<ItemPesanan> getItems() { return items; }
    public void setItems(List<ItemPesanan> items) { this.items = items; }

    public String getFormattedTanggal() {
        if (tanggalPesanan == null) return "-";
        return tanggalPesanan.format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm", Locale.forLanguageTag("id-ID")));
    }

    public int getJumlahBarang() {
        int total = 0;
        for (ItemPesanan item : items) {
            total += item.getJumlah();
        }
        return total;
    }
}
