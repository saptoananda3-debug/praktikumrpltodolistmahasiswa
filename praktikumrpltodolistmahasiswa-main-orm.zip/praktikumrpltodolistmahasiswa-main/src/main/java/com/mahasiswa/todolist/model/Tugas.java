package com.mahasiswa.todolist.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Entity Tugas Mahasiswa (dipetakan ke tabel "tugas").
 * Relasi ORM: banyak Tugas dimiliki satu MataKuliah (Many-to-One).
 */
@Entity
@Table(name = "tugas")
public class Tugas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nama tugas wajib diisi")
    @Size(max = 150, message = "Nama tugas maksimal 150 karakter")
    @Column(name = "nama_tugas", nullable = false, length = 150)
    private String namaTugas;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mata_kuliah_id")
    private MataKuliah mataKuliah;

    @Size(max = 1000, message = "Deskripsi maksimal 1000 karakter")
    @Column(length = 1000)
    private String deskripsi;

    @NotNull(message = "Tanggal deadline wajib diisi")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(nullable = false)
    private LocalDate deadline;

    @NotBlank(message = "Prioritas wajib dipilih")
    @Column(nullable = false, length = 20)
    private String prioritas = "Sedang"; // "Tinggi", "Sedang", "Rendah"

    @NotBlank(message = "Status wajib dipilih")
    @Column(nullable = false, length = 30)
    private String status = "Belum Dikerjakan"; // "Belum Dikerjakan", "Sedang Dikerjakan", "Selesai"

    public Tugas() {
    }

    public Tugas(String namaTugas, MataKuliah mataKuliah, String deskripsi, LocalDate deadline, String prioritas, String status) {
        this.namaTugas = namaTugas;
        this.mataKuliah = mataKuliah;
        this.deskripsi = deskripsi;
        this.deadline = deadline;
        this.prioritas = prioritas;
        this.status = status;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNamaTugas() { return namaTugas; }
    public void setNamaTugas(String namaTugas) { this.namaTugas = namaTugas; }

    public MataKuliah getMataKuliah() { return mataKuliah; }
    public void setMataKuliah(MataKuliah mataKuliah) { this.mataKuliah = mataKuliah; }

    public String getDeskripsi() { return deskripsi; }
    public void setDeskripsi(String deskripsi) { this.deskripsi = deskripsi; }

    public LocalDate getDeadline() { return deadline; }
    public void setDeadline(LocalDate deadline) { this.deadline = deadline; }

    public String getPrioritas() { return prioritas; }
    public void setPrioritas(String prioritas) { this.prioritas = prioritas; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // ---------- Helper (tidak disimpan ke database) ----------

    /** Terlambat bila deadline sudah lewat dan status belum selesai. Dihitung saat dibaca. */
    public boolean isTerlambat() {
        return deadline != null
                && deadline.isBefore(LocalDate.now())
                && !"Selesai".equalsIgnoreCase(status);
    }

    public String getNamaMataKuliah() {
        return mataKuliah != null ? mataKuliah.getNama() : "-";
    }

    public String getFormattedDeadline() {
        if (deadline == null) return "-";
        return deadline.format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.forLanguageTag("id-ID")));
    }
}
