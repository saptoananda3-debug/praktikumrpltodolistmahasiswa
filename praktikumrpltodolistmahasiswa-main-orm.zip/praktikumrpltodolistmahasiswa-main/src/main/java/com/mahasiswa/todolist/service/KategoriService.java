package com.mahasiswa.todolist.service;

import com.mahasiswa.todolist.model.Kategori;
import com.mahasiswa.todolist.repository.KategoriRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KategoriService {

    private final KategoriRepository kategoriRepository;

    public KategoriService(KategoriRepository kategoriRepository) {
        this.kategoriRepository = kategoriRepository;
    }

    public List<Kategori> getAll() {
        return kategoriRepository.findAllByOrderByNamaAsc();
    }
}
