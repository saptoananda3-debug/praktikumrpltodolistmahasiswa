package com.mahasiswa.todolist.service;

import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.MataKuliah;
import com.mahasiswa.todolist.model.Tugas;
import com.mahasiswa.todolist.repository.MataKuliahRepository;
import com.mahasiswa.todolist.repository.TugasRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service layer Tugas. Data kini dibaca/ditulis ke database lewat ORM (Spring Data JPA + Hibernate).
 */
@Service
@Transactional(readOnly = true)
public class TugasService {

    public static final String STATUS_BELUM = "Belum Dikerjakan";
    public static final String STATUS_SEDANG = "Sedang Dikerjakan";
    public static final String STATUS_SELESAI = "Selesai";

    private final TugasRepository tugasRepository;
    private final MataKuliahRepository mataKuliahRepository;

    public TugasService(TugasRepository tugasRepository, MataKuliahRepository mataKuliahRepository) {
        this.tugasRepository = tugasRepository;
        this.mataKuliahRepository = mataKuliahRepository;
    }

    public List<Tugas> getAllTugas() {
        return tugasRepository.findAllWithMataKuliah();
    }

    public Optional<Tugas> findById(Long id) {
        return tugasRepository.findById(id);
    }

    public long getTotalTugas() {
        return tugasRepository.count();
    }

    public long getTotalBelumDikerjakan() {
        return tugasRepository.countByStatus(STATUS_BELUM);
    }

    public long getTotalSedangDikerjakan() {
        return tugasRepository.countByStatus(STATUS_SEDANG);
    }

    public long getTotalSelesai() {
        return tugasRepository.countByStatus(STATUS_SELESAI);
    }

    public List<MataKuliah> getMataKuliahList() {
        return mataKuliahRepository.findAllByOrderByNamaAsc();
    }

    /** Simpan (tambah atau ubah) tugas. */
    @Transactional
    public Tugas simpan(Tugas tugas, Long mataKuliahId) {
        MataKuliah mk = mataKuliahRepository.findById(mataKuliahId)
                .orElseThrow(() -> new BisnisException("Mata kuliah tidak ditemukan."));
        tugas.setMataKuliah(mk);
        return tugasRepository.save(tugas);
    }

    @Transactional
    public void tandaiSelesai(Long id) {
        Tugas tugas = tugasRepository.findById(id)
                .orElseThrow(() -> new BisnisException("Tugas tidak ditemukan."));
        tugas.setStatus(STATUS_SELESAI); // entity "managed": perubahan otomatis di-UPDATE saat commit
    }

    @Transactional
    public void hapus(Long id) {
        if (!tugasRepository.existsById(id)) {
            throw new BisnisException("Tugas tidak ditemukan.");
        }
        tugasRepository.deleteById(id);
    }
}
