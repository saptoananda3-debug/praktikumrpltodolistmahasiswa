package com.mahasiswa.todolist.controller;

import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.Pelanggan;
import com.mahasiswa.todolist.service.PelangganService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
@RequestMapping("/pelanggan")
public class PelangganController {

    private final PelangganService pelangganService;

    public PelangganController(PelangganService pelangganService) {
        this.pelangganService = pelangganService;
    }

    @GetMapping
    public String daftar(Model model) {
        model.addAttribute("activePage", "pelanggan");
        model.addAttribute("pageTitle", "Data Pelanggan");
        model.addAttribute("daftarPelanggan", pelangganService.getAll());
        return "pelanggan/index";
    }

    @GetMapping("/tambah")
    public String formTambah(Model model) {
        isiModelForm(model, new Pelanggan(), false);
        return "pelanggan/form";
    }

    @GetMapping("/{id}/edit")
    public String formEdit(@PathVariable Long id, Model model, RedirectAttributes redirect) {
        Optional<Pelanggan> pelanggan = pelangganService.findById(id);
        if (pelanggan.isEmpty()) {
            redirect.addFlashAttribute("galat", "Pelanggan tidak ditemukan.");
            return "redirect:/pelanggan";
        }
        isiModelForm(model, pelanggan.get(), true);
        return "pelanggan/form";
    }

    @PostMapping("/simpan")
    public String simpan(@Valid @ModelAttribute("pelanggan") Pelanggan pelanggan,
                         BindingResult binding,
                         Model model,
                         RedirectAttributes redirect) {
        if (binding.hasErrors()) {
            isiModelForm(model, pelanggan, pelanggan.getId() != null);
            return "pelanggan/form";
        }
        boolean baru = pelanggan.getId() == null;
        if (!baru) {
            // createdAt tidak ada di form; pertahankan nilai lama agar tidak tertimpa null
            pelangganService.findById(pelanggan.getId())
                    .ifPresent(lama -> pelanggan.setCreatedAt(lama.getCreatedAt()));
        }
        pelangganService.simpan(pelanggan);
        redirect.addFlashAttribute("sukses", baru ? "Pelanggan berhasil ditambahkan." : "Data pelanggan diperbarui.");
        return "redirect:/pelanggan";
    }

    @PostMapping("/{id}/hapus")
    public String hapus(@PathVariable Long id, RedirectAttributes redirect) {
        try {
            pelangganService.hapus(id);
            redirect.addFlashAttribute("sukses", "Pelanggan berhasil dihapus.");
        } catch (BisnisException e) {
            redirect.addFlashAttribute("galat", e.getMessage());
        }
        return "redirect:/pelanggan";
    }

    private void isiModelForm(Model model, Pelanggan pelanggan, boolean edit) {
        model.addAttribute("activePage", "pelanggan");
        model.addAttribute("pageTitle", edit ? "Ubah Pelanggan" : "Tambah Pelanggan");
        model.addAttribute("pelanggan", pelanggan);
        model.addAttribute("modeEdit", edit);
    }
}
