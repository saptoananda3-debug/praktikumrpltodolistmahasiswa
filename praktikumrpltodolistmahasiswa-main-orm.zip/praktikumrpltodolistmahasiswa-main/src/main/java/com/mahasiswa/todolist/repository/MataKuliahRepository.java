package com.mahasiswa.todolist.repository;

import com.mahasiswa.todolist.model.MataKuliah;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MataKuliahRepository extends JpaRepository<MataKuliah, Long> {

    List<MataKuliah> findAllByOrderByNamaAsc();
}
