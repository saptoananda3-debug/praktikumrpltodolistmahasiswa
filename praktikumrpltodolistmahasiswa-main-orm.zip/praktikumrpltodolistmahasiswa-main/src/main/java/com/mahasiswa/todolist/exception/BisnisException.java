package com.mahasiswa.todolist.exception;

/** Pelanggaran aturan bisnis (mis. stok tidak cukup). Pesannya aman ditampilkan ke pengguna. */
public class BisnisException extends RuntimeException {

    public BisnisException(String message) {
        super(message);
    }
}
