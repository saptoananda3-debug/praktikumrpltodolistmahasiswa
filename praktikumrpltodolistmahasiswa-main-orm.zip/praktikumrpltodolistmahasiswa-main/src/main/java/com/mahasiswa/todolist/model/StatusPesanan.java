package com.mahasiswa.todolist.model;

import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/** Siklus hidup sebuah pesanan. */
public enum StatusPesanan {

    MENUNGGU_PEMBAYARAN("Menunggu Pembayaran", "pesanan-menunggu"),
    DIBAYAR("Dibayar", "pesanan-dibayar"),
    DIKIRIM("Dikirim", "pesanan-dikirim"),
    SELESAI("Selesai", "pesanan-selesai"),
    DIBATALKAN("Dibatalkan", "pesanan-batal");

    /** Status yang dihitung sebagai penjualan (uang sudah/akan pasti masuk). */
    public static final Set<StatusPesanan> STATUS_PENJUALAN = EnumSet.of(DIBAYAR, DIKIRIM, SELESAI);

    private final String label;
    private final String cssClass;

    StatusPesanan(String label, String cssClass) {
        this.label = label;
        this.cssClass = cssClass;
    }

    public String getLabel() {
        return label;
    }

    public String getCssClass() {
        return cssClass;
    }

    /** Status berikutnya yang diperbolehkan dari status ini. */
    public List<StatusPesanan> getNextStatuses() {
        switch (this) {
            case MENUNGGU_PEMBAYARAN:
                return List.of(DIBAYAR, DIBATALKAN);
            case DIBAYAR:
                return List.of(DIKIRIM, DIBATALKAN);
            case DIKIRIM:
                return List.of(SELESAI);
            default:
                return List.of();
        }
    }

    public boolean bolehBerubahKe(StatusPesanan tujuan) {
        return getNextStatuses().contains(tujuan);
    }
}
