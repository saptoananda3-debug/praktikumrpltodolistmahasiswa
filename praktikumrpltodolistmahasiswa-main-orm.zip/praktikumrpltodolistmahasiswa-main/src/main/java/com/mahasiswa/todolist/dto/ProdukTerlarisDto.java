package com.mahasiswa.todolist.dto;

import java.math.BigDecimal;

/** Hasil query agregasi produk terlaris (JPQL constructor expression). */
public class ProdukTerlarisDto {

    private final String nama;
    private final Long terjual;
    private final BigDecimal omzet;

    public ProdukTerlarisDto(String nama, Long terjual, BigDecimal omzet) {
        this.nama = nama;
        this.terjual = terjual;
        this.omzet = omzet;
    }

    public String getNama() { return nama; }
    public Long getTerjual() { return terjual; }
    public BigDecimal getOmzet() { return omzet; }
}
