package com.mahasiswa.todolist.controller;

import com.mahasiswa.todolist.service.LaporanService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/** Dashboard penjualan Toko Mahasiswa. */
@Controller
public class TokoController {

    private final LaporanService laporanService;

    public TokoController(LaporanService laporanService) {
        this.laporanService = laporanService;
    }

    @GetMapping("/toko")
    public String dashboardToko(Model model) {
        model.addAttribute("activePage", "toko");
        model.addAttribute("pageTitle", "Dashboard Penjualan");
        model.addAttribute("ringkasan", laporanService.getRingkasan());
        model.addAttribute("produkTerlaris", laporanService.getProdukTerlaris(5));
        model.addAttribute("stokMenipis", laporanService.getStokMenipis());
        model.addAttribute("batasStok", LaporanService.BATAS_STOK_MENIPIS);
        model.addAttribute("pesananTerbaru", laporanService.getPesananTerbaru(5));
        return "toko/dashboard";
    }
}
