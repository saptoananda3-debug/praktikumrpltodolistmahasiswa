package com.mahasiswa.todolist.service;

import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.Kategori;
import com.mahasiswa.todolist.model.Produk;
import com.mahasiswa.todolist.repository.ItemPesananRepository;
import com.mahasiswa.todolist.repository.KategoriRepository;
import com.mahasiswa.todolist.repository.ProdukRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class ProdukService {

    private final ProdukRepository produkRepository;
    private final KategoriRepository kategoriRepository;
    private final ItemPesananRepository itemPesananRepository;

    public ProdukService(ProdukRepository produkRepository,
                         KategoriRepository kategoriRepository,
                         ItemPesananRepository itemPesananRepository) {
        this.produkRepository = produkRepository;
        this.kategoriRepository = kategoriRepository;
        this.itemPesananRepository = itemPesananRepository;
    }

    public List<Produk> getAll() {
        return produkRepository.findAllWithKategori();
    }

    public List<Produk> getTersedia() {
        return produkRepository.findTersedia();
    }

    public Optional<Produk> findById(Long id) {
        return produkRepository.findById(id);
    }

    @Transactional
    public Produk simpan(Produk produk, Long kategoriId) {
        Kategori kategori = kategoriRepository.findById(kategoriId)
                .orElseThrow(() -> new BisnisException("Kategori tidak ditemukan."));
        produk.setKategori(kategori);
        return produkRepository.save(produk);
    }

    /**
     * Hapus produk. Bila produk sudah pernah dipesan, riwayat pesanan harus tetap utuh,
     * sehingga produk hanya dinonaktifkan.
     *
     * @return true bila benar-benar dihapus, false bila hanya dinonaktifkan
     */
    @Transactional
    public boolean hapusAtauNonaktifkan(Long id) {
        Produk produk = produkRepository.findById(id)
                .orElseThrow(() -> new BisnisException("Produk tidak ditemukan."));
        if (itemPesananRepository.existsByProdukId(id)) {
            produk.setAktif(false);
            return false;
        }
        produkRepository.delete(produk);
        return true;
    }
}
