package com.mahasiswa.todolist.repository;

import com.mahasiswa.todolist.model.Pesanan;
import com.mahasiswa.todolist.model.StatusPesanan;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface PesananRepository extends JpaRepository<Pesanan, Long> {

    @Query("select p from Pesanan p join fetch p.pelanggan order by p.tanggalPesanan desc, p.id desc")
    List<Pesanan> findAllWithPelanggan();

    @Query("select p from Pesanan p join fetch p.pelanggan where p.status = :status order by p.tanggalPesanan desc, p.id desc")
    List<Pesanan> findByStatusWithPelanggan(@Param("status") StatusPesanan status);

    /** Pesanan terbaru (dibatasi lewat Pageable) untuk dashboard. */
    @Query("select p from Pesanan p join fetch p.pelanggan order by p.tanggalPesanan desc, p.id desc")
    List<Pesanan> findTerbaru(Pageable pageable);

    /** Detail pesanan lengkap: pelanggan + item + produk dalam satu query. */
    @Query("select distinct p from Pesanan p join fetch p.pelanggan left join fetch p.items i left join fetch i.produk where p.id = :id")
    Optional<Pesanan> findDetailById(@Param("id") Long id);

    boolean existsByPelangganId(Long pelangganId);

    long countByStatus(StatusPesanan status);

    @Query("select count(p) from Pesanan p where p.status in :statuses")
    long countByStatusIn(@Param("statuses") Collection<StatusPesanan> statuses);

    /** Bisa bernilai null bila belum ada data; ditangani di service. */
    @Query("select sum(p.totalHarga) from Pesanan p where p.status in :statuses")
    BigDecimal sumTotalByStatusIn(@Param("statuses") Collection<StatusPesanan> statuses);
}
