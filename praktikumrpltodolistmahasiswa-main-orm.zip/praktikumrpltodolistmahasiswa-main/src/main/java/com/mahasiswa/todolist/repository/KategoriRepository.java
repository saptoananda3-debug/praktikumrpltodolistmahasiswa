package com.mahasiswa.todolist.repository;

import com.mahasiswa.todolist.model.Kategori;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface KategoriRepository extends JpaRepository<Kategori, Long> {

    List<Kategori> findAllByOrderByNamaAsc();
}
