package com.mahasiswa.todolist.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Produk yang dijual di Toko Mahasiswa. Many-to-One ke Kategori. */
@Entity
@Table(name = "produk")
public class Produk {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nama produk wajib diisi")
    @Size(max = 120, message = "Nama produk maksimal 120 karakter")
    @Column(nullable = false, length = 120)
    private String nama;

    @Size(max = 500, message = "Deskripsi maksimal 500 karakter")
    @Column(length = 500)
    private String deskripsi;

    @NotNull(message = "Harga wajib diisi")
    @DecimalMin(value = "0.00", message = "Harga tidak boleh negatif")
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal harga;

    @NotNull(message = "Stok wajib diisi")
    @Min(value = 0, message = "Stok tidak boleh negatif")
    @Column(nullable = false)
    private Integer stok = 0;

    /** Produk nonaktif tidak tampil di form pesanan baru. */
    @Column(nullable = false)
    private boolean aktif = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "kategori_id")
    private Kategori kategori;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    public Produk() {
    }

    public Produk(String nama, String deskripsi, BigDecimal harga, Integer stok, Kategori kategori) {
        this.nama = nama;
        this.deskripsi = deskripsi;
        this.harga = harga;
        this.stok = stok;
        this.kategori = kategori;
    }

    @PrePersist
    void prePersist() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getDeskripsi() { return deskripsi; }
    public void setDeskripsi(String deskripsi) { this.deskripsi = deskripsi; }

    public BigDecimal getHarga() { return harga; }
    public void setHarga(BigDecimal harga) { this.harga = harga; }

    public Integer getStok() { return stok; }
    public void setStok(Integer stok) { this.stok = stok; }

    public boolean isAktif() { return aktif; }
    public void setAktif(boolean aktif) { this.aktif = aktif; }

    public Kategori getKategori() { return kategori; }
    public void setKategori(Kategori kategori) { this.kategori = kategori; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public String getNamaKategori() {
        return kategori != null ? kategori.getNama() : "-";
    }
}
