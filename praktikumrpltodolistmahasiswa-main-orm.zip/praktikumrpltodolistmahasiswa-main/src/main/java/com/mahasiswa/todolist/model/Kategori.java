package com.mahasiswa.todolist.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

/** Kategori produk toko. One-to-Many ke Produk. */
@Entity
@Table(name = "kategori")
public class Kategori {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 80)
    private String nama;

    @OneToMany(mappedBy = "kategori")
    private List<Produk> daftarProduk = new ArrayList<>();

    public Kategori() {
    }

    public Kategori(String nama) {
        this.nama = nama;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public List<Produk> getDaftarProduk() { return daftarProduk; }
    public void setDaftarProduk(List<Produk> daftarProduk) { this.daftarProduk = daftarProduk; }
}
