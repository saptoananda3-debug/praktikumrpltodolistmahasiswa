package com.mahasiswa.todolist.repository;

import com.mahasiswa.todolist.model.Pelanggan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PelangganRepository extends JpaRepository<Pelanggan, Long> {

    List<Pelanggan> findAllByOrderByNamaAsc();
}
