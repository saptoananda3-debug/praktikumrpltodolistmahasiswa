package com.mahasiswa.todolist.repository;

import com.mahasiswa.todolist.model.Tugas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * Repository ORM untuk entitas Tugas.
 *
 * Perbandingan dengan materi (Pertemuan 4):
 *   Tanpa ORM : SELECT * FROM tugas;            SELECT * FROM tugas WHERE id = 1;
 *   Dengan ORM: tugasRepository.findAll();      tugasRepository.findById(1L);
 */
public interface TugasRepository extends JpaRepository<Tugas, Long> {

    /** JPQL + JOIN FETCH: ambil tugas beserta mata kuliahnya dalam 1 query (hindari N+1). */
    @Query("select t from Tugas t left join fetch t.mataKuliah order by t.deadline asc")
    List<Tugas> findAllWithMataKuliah();

    /** Query method turunan dari nama method (tanpa menulis SQL/JPQL). */
    long countByStatus(String status);

    List<Tugas> findByStatus(String status);
}
