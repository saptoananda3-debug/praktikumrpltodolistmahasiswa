package com.mahasiswa.todolist.config;

import com.mahasiswa.todolist.model.*;
import com.mahasiswa.todolist.repository.*;
import com.mahasiswa.todolist.service.PesananService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Mengisi data contoh saat aplikasi pertama kali dijalankan (hanya jika tabel masih kosong).
 * Nonaktifkan dengan app.seed.enabled=false.
 */
@Component
public class DataSeeder implements ApplicationRunner {

    private final boolean aktif;
    private final MataKuliahRepository mataKuliahRepository;
    private final TugasRepository tugasRepository;
    private final KategoriRepository kategoriRepository;
    private final ProdukRepository produkRepository;
    private final PelangganRepository pelangganRepository;
    private final PesananService pesananService;

    public DataSeeder(@Value("${app.seed.enabled:true}") boolean aktif,
                      MataKuliahRepository mataKuliahRepository,
                      TugasRepository tugasRepository,
                      KategoriRepository kategoriRepository,
                      ProdukRepository produkRepository,
                      PelangganRepository pelangganRepository,
                      PesananService pesananService) {
        this.aktif = aktif;
        this.mataKuliahRepository = mataKuliahRepository;
        this.tugasRepository = tugasRepository;
        this.kategoriRepository = kategoriRepository;
        this.produkRepository = produkRepository;
        this.pelangganRepository = pelangganRepository;
        this.pesananService = pesananService;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (!aktif) {
            return;
        }
        if (mataKuliahRepository.count() == 0) {
            seedAkademik();
        }
        if (kategoriRepository.count() == 0) {
            seedToko();
        }
    }

    private void seedAkademik() {
        MataKuliah ai = new MataKuliah("TI301", "Kecerdasan Buatan", 3);
        MataKuliah jarkom = new MataKuliah("TI302", "Jaringan Komputer", 3);
        MataKuliah basdat = new MataKuliah("TI303", "Basis Data Lanjut", 3);
        MataKuliah web = new MataKuliah("TI304", "Pemrograman Web", 3);
        MataKuliah etika = new MataKuliah("TI305", "Etika Profesi TI", 2);
        MataKuliah ipk = new MataKuliah("TI306", "Interaksi Manusia dan Komputer", 3);
        MataKuliah rpl = new MataKuliah("TI307", "Rekayasa Perangkat Lunak", 3);
        MataKuliah sisop = new MataKuliah("TI308", "Sistem Operasi", 3);
        mataKuliahRepository.saveAll(List.of(ai, jarkom, basdat, web, etika, ipk, rpl, sisop));

        LocalDate hariIni = LocalDate.now();
        tugasRepository.saveAll(List.of(
                new Tugas("Makalah Penerapan Neural Network pada Citra Medis", ai,
                        "Membuat makalah ilmiah minimal 10 halaman beserta referensi IEEE terbaru.",
                        hariIni.plusDays(3), "Tinggi", "Sedang Dikerjakan"),
                new Tugas("Praktikum Routing OSPF & VLAN Modul 4", jarkom,
                        "Konfigurasi topologi jaringan pada Cisco Packet Tracer dan kumpulkan file .pkt beserta laporan.",
                        hariIni.plusDays(7), "Sedang", "Belum Dikerjakan"),
                new Tugas("Normalisasi Database Toko Online ke 3NF & BCNF", basdat,
                        "Menganalisis skema tabel relasional unnormalized dan membuat diagram ERD relasi baru.",
                        hariIni.minusDays(2), "Tinggi", "Belum Dikerjakan"),
                new Tugas("Implementasi RESTful API Produk dengan Spring Boot", web,
                        "Membuat endpoint CRUD produk dengan validasi input dan exception handler.",
                        hariIni.plusDays(10), "Tinggi", "Sedang Dikerjakan"),
                new Tugas("Analisis Kasus Pelanggaran Hak Cipta Perangkat Lunak", etika,
                        "Review studi kasus pelanggaran lisensi open source vs proprietary.",
                        hariIni.minusDays(5), "Rendah", "Selesai"),
                new Tugas("Desain UI/UX Wireframe Dashboard Mobile", ipk,
                        "Membuat prototype high-fidelity di Figma untuk aplikasi pemantau aktivitas harian.",
                        hariIni.minusDays(1), "Sedang", "Selesai"),
                new Tugas("Laporan Praktikum ORM dengan Hibernate (Pertemuan 4)", rpl,
                        "Implementasi entity, repository, dan relasi antar tabel menggunakan Spring Data JPA.",
                        hariIni.plusDays(5), "Tinggi", "Sedang Dikerjakan")
        ));
    }

    private void seedToko() {
        Kategori alatKuliah = new Kategori("Alat Tulis & Perlengkapan Kuliah");
        Kategori digital = new Kategori("Template & Materi Digital");
        Kategori aksesori = new Kategori("Aksesori Mahasiswa");
        kategoriRepository.saveAll(List.of(alatKuliah, digital, aksesori));

        Produk buku = new Produk("Buku Catatan A5 Hardcover", "Buku catatan 100 halaman, kertas 80 gsm.",
                new BigDecimal("25000"), 40, alatKuliah);
        Produk pulpen = new Produk("Pulpen Gel 0.5mm (isi 12)", "Tinta hitam, cepat kering.",
                new BigDecimal("30000"), 30, alatKuliah);
        Produk highlighter = new Produk("Set Highlighter Pastel (6 warna)", "Cocok untuk menandai materi kuliah.",
                new BigDecimal("35000"), 3, alatKuliah);
        Produk templateLaporan = new Produk("Template Laporan Praktikum (Word)", "Format rapi: cover, daftar isi, bab, daftar pustaka.",
                new BigDecimal("15000"), 999, digital);
        Produk templateCv = new Produk("Template CV & Portofolio Fresh Graduate", "Siap edit di Canva dan Word.",
                new BigDecimal("20000"), 999, digital);
        Produk totebag = new Produk("Tote Bag Kanvas Anak Teknik", "Kanvas tebal dengan sablon desain eksklusif.",
                new BigDecimal("55000"), 20, aksesori);
        Produk lanyard = new Produk("Lanyard + ID Card Holder", "Lanyard 2 cm, holder transparan.",
                new BigDecimal("12000"), 4, aksesori);
        Produk botol = new Produk("Botol Minum 750ml", "BPA free, bisa dipakai membawa air panas.",
                new BigDecimal("65000"), 15, aksesori);
        produkRepository.saveAll(List.of(buku, pulpen, highlighter, templateLaporan, templateCv, totebag, lanyard, botol));

        Pelanggan budi = pelangganRepository.save(new Pelanggan("Budi Santoso", "budi@mail.com", "081234567801", "Jl. Melati No. 5, Jakarta"));
        Pelanggan siti = pelangganRepository.save(new Pelanggan("Siti Rahma", "siti@mail.com", "081234567802", "Kos Mawar, Jl. Kampus Raya 12, Depok"));
        Pelanggan andi = pelangganRepository.save(new Pelanggan("Andi Pratama", "andi@mail.com", "081234567803", "Jl. Kenanga No. 21, Bekasi"));
        pelangganRepository.save(new Pelanggan("Dewi Lestari", null, "081234567804", "Asrama Putri Blok C, Tangerang"));

        // Transaksi contoh dibuat lewat service agar aturan bisnis (stok, total) ikut berjalan.
        Pesanan p1 = pesananService.buatPesanan(budi.getId(),
                List.of(buku.getId(), pulpen.getId()), List.of(2, 1), "Kirim sore hari");
        pesananService.ubahStatus(p1.getId(), StatusPesanan.DIBAYAR);
        pesananService.ubahStatus(p1.getId(), StatusPesanan.DIKIRIM);
        pesananService.ubahStatus(p1.getId(), StatusPesanan.SELESAI);

        Pesanan p2 = pesananService.buatPesanan(siti.getId(),
                List.of(templateLaporan.getId(), totebag.getId(), buku.getId()), List.of(1, 1, 3), null);
        pesananService.ubahStatus(p2.getId(), StatusPesanan.DIBAYAR);

        Pesanan p3 = pesananService.buatPesanan(andi.getId(),
                List.of(botol.getId(), highlighter.getId()), List.of(1, 1), "COD di kampus");
        pesananService.ubahStatus(p3.getId(), StatusPesanan.DIBAYAR);
        pesananService.ubahStatus(p3.getId(), StatusPesanan.DIKIRIM);

        pesananService.buatPesanan(siti.getId(), List.of(templateCv.getId()), List.of(1), null);

        Pesanan p5 = pesananService.buatPesanan(budi.getId(), List.of(lanyard.getId()), List.of(2), "Batal, salah pilih");
        pesananService.ubahStatus(p5.getId(), StatusPesanan.DIBATALKAN);
    }
}
