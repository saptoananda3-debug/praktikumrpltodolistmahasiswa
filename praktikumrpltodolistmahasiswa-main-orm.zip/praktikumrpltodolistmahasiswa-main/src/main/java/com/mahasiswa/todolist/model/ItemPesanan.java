package com.mahasiswa.todolist.model;

import jakarta.persistence.*;

import java.math.BigDecimal;

/**
 * Baris item dalam sebuah pesanan.
 * Harga disalin (snapshot) saat transaksi, sehingga perubahan harga produk
 * di kemudian hari tidak mengubah riwayat pesanan.
 */
@Entity
@Table(name = "item_pesanan")
public class ItemPesanan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "pesanan_id", nullable = false)
    private Pesanan pesanan;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "produk_id", nullable = false)
    private Produk produk;

    @Column(nullable = false)
    private int jumlah;

    @Column(name = "harga_satuan", nullable = false, precision = 12, scale = 2)
    private BigDecimal hargaSatuan;

    public ItemPesanan() {
    }

    public ItemPesanan(Produk produk, int jumlah) {
        this.produk = produk;
        this.jumlah = jumlah;
        this.hargaSatuan = produk.getHarga();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Pesanan getPesanan() { return pesanan; }
    public void setPesanan(Pesanan pesanan) { this.pesanan = pesanan; }

    public Produk getProduk() { return produk; }
    public void setProduk(Produk produk) { this.produk = produk; }

    public int getJumlah() { return jumlah; }
    public void setJumlah(int jumlah) { this.jumlah = jumlah; }

    public BigDecimal getHargaSatuan() { return hargaSatuan; }
    public void setHargaSatuan(BigDecimal hargaSatuan) { this.hargaSatuan = hargaSatuan; }

    public BigDecimal getSubtotal() {
        if (hargaSatuan == null) return BigDecimal.ZERO;
        return hargaSatuan.multiply(BigDecimal.valueOf(jumlah));
    }
}
