package com.mahasiswa.todolist.controller;

import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.Tugas;
import com.mahasiswa.todolist.service.TugasService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

/**
 * Controller Tugas: daftar, tambah, ubah, hapus, dan tandai selesai.
 */
@Controller
@RequestMapping("/tugas")
public class TugasController {

    private final TugasService tugasService;

    public TugasController(TugasService tugasService) {
        this.tugasService = tugasService;
    }

    @GetMapping
    public String daftarTugas(Model model) {
        model.addAttribute("activePage", "tugas");
        model.addAttribute("pageTitle", "Daftar Tugas Perkuliahan");
        model.addAttribute("daftarTugas", tugasService.getAllTugas());
        model.addAttribute("mataKuliahList", tugasService.getMataKuliahList());
        return "tugas/index";
    }

    @GetMapping("/tambah")
    public String formTambah(Model model) {
        isiModelForm(model, new Tugas(), null, false);
        return "tugas/form";
    }

    @GetMapping("/{id}/edit")
    public String formEdit(@PathVariable Long id, Model model, RedirectAttributes redirect) {
        Optional<Tugas> tugas = tugasService.findById(id);
        if (tugas.isEmpty()) {
            redirect.addFlashAttribute("galat", "Tugas tidak ditemukan.");
            return "redirect:/tugas";
        }
        Long matkulId = tugas.get().getMataKuliah() != null ? tugas.get().getMataKuliah().getId() : null;
        isiModelForm(model, tugas.get(), matkulId, true);
        return "tugas/form";
    }

    @PostMapping("/simpan")
    public String simpan(@Valid @ModelAttribute("tugas") Tugas tugas,
                         BindingResult binding,
                         @RequestParam(required = false) Long mataKuliahId,
                         Model model,
                         RedirectAttributes redirect) {
        if (mataKuliahId == null) {
            binding.addError(new FieldError("tugas", "mataKuliah", "Mata kuliah wajib dipilih"));
        }
        if (binding.hasErrors()) {
            isiModelForm(model, tugas, mataKuliahId, tugas.getId() != null);
            return "tugas/form";
        }
        boolean baru = tugas.getId() == null;
        try {
            tugasService.simpan(tugas, mataKuliahId);
        } catch (BisnisException e) {
            redirect.addFlashAttribute("galat", e.getMessage());
            return "redirect:/tugas";
        }
        redirect.addFlashAttribute("sukses", baru ? "Tugas berhasil ditambahkan." : "Tugas berhasil diperbarui.");
        return "redirect:/tugas";
    }

    @PostMapping("/{id}/selesai")
    public String tandaiSelesai(@PathVariable Long id, RedirectAttributes redirect) {
        try {
            tugasService.tandaiSelesai(id);
            redirect.addFlashAttribute("sukses", "Tugas ditandai selesai.");
        } catch (BisnisException e) {
            redirect.addFlashAttribute("galat", e.getMessage());
        }
        return "redirect:/tugas";
    }

    @PostMapping("/{id}/hapus")
    public String hapus(@PathVariable Long id, RedirectAttributes redirect) {
        try {
            tugasService.hapus(id);
            redirect.addFlashAttribute("sukses", "Tugas berhasil dihapus.");
        } catch (BisnisException e) {
            redirect.addFlashAttribute("galat", e.getMessage());
        }
        return "redirect:/tugas";
    }

    private void isiModelForm(Model model, Tugas tugas, Long matkulId, boolean edit) {
        model.addAttribute("activePage", edit ? "tugas" : "tambah");
        model.addAttribute("pageTitle", edit ? "Ubah Tugas" : "Tambah Tugas Baru");
        model.addAttribute("tugas", tugas);
        model.addAttribute("mataKuliahList", tugasService.getMataKuliahList());
        model.addAttribute("selectedMatkulId", matkulId);
        model.addAttribute("modeEdit", edit);
    }
}
