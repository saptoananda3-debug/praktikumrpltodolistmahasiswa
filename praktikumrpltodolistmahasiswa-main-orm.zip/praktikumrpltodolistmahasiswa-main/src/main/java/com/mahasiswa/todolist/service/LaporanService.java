package com.mahasiswa.todolist.service;

import com.mahasiswa.todolist.dto.ProdukTerlarisDto;
import com.mahasiswa.todolist.dto.RingkasanToko;
import com.mahasiswa.todolist.model.Pesanan;
import com.mahasiswa.todolist.model.Produk;
import com.mahasiswa.todolist.model.StatusPesanan;
import com.mahasiswa.todolist.repository.ItemPesananRepository;
import com.mahasiswa.todolist.repository.PesananRepository;
import com.mahasiswa.todolist.repository.ProdukRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/** Data laporan penjualan untuk dashboard toko. */
@Service
@Transactional(readOnly = true)
public class LaporanService {

    public static final int BATAS_STOK_MENIPIS = 5;

    private final PesananRepository pesananRepository;
    private final ItemPesananRepository itemPesananRepository;
    private final ProdukRepository produkRepository;

    public LaporanService(PesananRepository pesananRepository,
                          ItemPesananRepository itemPesananRepository,
                          ProdukRepository produkRepository) {
        this.pesananRepository = pesananRepository;
        this.itemPesananRepository = itemPesananRepository;
        this.produkRepository = produkRepository;
    }

    public RingkasanToko getRingkasan() {
        BigDecimal pendapatan = pesananRepository.sumTotalByStatusIn(StatusPesanan.STATUS_PENJUALAN);
        return new RingkasanToko(
                pendapatan != null ? pendapatan : BigDecimal.ZERO,
                pesananRepository.countByStatusIn(StatusPesanan.STATUS_PENJUALAN),
                pesananRepository.countByStatus(StatusPesanan.MENUNGGU_PEMBAYARAN),
                produkRepository.countByAktifTrue());
    }

    public List<ProdukTerlarisDto> getProdukTerlaris(int limit) {
        return itemPesananRepository.findProdukTerlaris(StatusPesanan.STATUS_PENJUALAN, PageRequest.of(0, limit));
    }

    public List<Produk> getStokMenipis() {
        return produkRepository.findByAktifTrueAndStokLessThanEqualOrderByStokAsc(BATAS_STOK_MENIPIS);
    }

    public List<Pesanan> getPesananTerbaru(int limit) {
        return pesananRepository.findTerbaru(PageRequest.of(0, limit));
    }
}
