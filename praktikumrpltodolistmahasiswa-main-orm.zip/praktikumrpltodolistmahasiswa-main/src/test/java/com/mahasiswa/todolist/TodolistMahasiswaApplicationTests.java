package com.mahasiswa.todolist;

import com.mahasiswa.todolist.model.MataKuliah;
import com.mahasiswa.todolist.model.Tugas;
import com.mahasiswa.todolist.service.TugasService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test halaman akademik (tugas). Memakai profil "test" -> H2 in-memory, tanpa MySQL.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class TodolistMahasiswaApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private TugasService tugasService;

    @Test
    void contextLoads() {
    }

    @Test
    void testDashboardRoute() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"))
                .andExpect(model().attributeExists("totalTugas", "belumDikerjakan", "sedangDikerjakan", "selesai", "daftarTugas"));

        mockMvc.perform(get("/dashboard"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"));
    }

    @Test
    void testDataSeederMengisiDatabase() {
        assertTrue(tugasService.getTotalTugas() >= 7, "Seeder harus mengisi data tugas");
        assertTrue(tugasService.getMataKuliahList().size() >= 8, "Seeder harus mengisi mata kuliah");
    }

    @Test
    void testDaftarTugasRoute() throws Exception {
        mockMvc.perform(get("/tugas"))
                .andExpect(status().isOk())
                .andExpect(view().name("tugas/index"))
                .andExpect(model().attributeExists("daftarTugas", "mataKuliahList"));
    }

    @Test
    void testTambahTugasRoute() throws Exception {
        mockMvc.perform(get("/tugas/tambah"))
                .andExpect(status().isOk())
                .andExpect(view().name("tugas/form"))
                .andExpect(model().attributeExists("tugas", "mataKuliahList"));
    }

    @Test
    void testEditTugasRoute() throws Exception {
        Tugas pertama = tugasService.getAllTugas().get(0);
        mockMvc.perform(get("/tugas/" + pertama.getId() + "/edit"))
                .andExpect(status().isOk())
                .andExpect(view().name("tugas/form"));
    }

    @Test
    void testSimpanTugasTanpaNamaGagalValidasi() throws Exception {
        MataKuliah mk = tugasService.getMataKuliahList().get(0);
        mockMvc.perform(post("/tugas/simpan")
                        .param("namaTugas", "")
                        .param("deadline", "2030-01-01")
                        .param("prioritas", "Sedang")
                        .param("status", "Belum Dikerjakan")
                        .param("mataKuliahId", String.valueOf(mk.getId())))
                .andExpect(status().isOk())
                .andExpect(view().name("tugas/form"))
                .andExpect(model().attributeHasFieldErrors("tugas", "namaTugas"));
    }

    @Test
    void testSimpanTugasBerhasilRedirect() throws Exception {
        MataKuliah mk = tugasService.getMataKuliahList().get(0);
        long sebelum = tugasService.getTotalTugas();
        mockMvc.perform(post("/tugas/simpan")
                        .param("namaTugas", "Tugas dari unit test")
                        .param("deadline", "2030-01-01")
                        .param("prioritas", "Sedang")
                        .param("status", "Belum Dikerjakan")
                        .param("mataKuliahId", String.valueOf(mk.getId())))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/tugas"));
        assertTrue(tugasService.getTotalTugas() == sebelum + 1);
    }
}
