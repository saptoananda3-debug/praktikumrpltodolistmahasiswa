package com.mahasiswa.todolist;

import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.Kategori;
import com.mahasiswa.todolist.model.Pelanggan;
import com.mahasiswa.todolist.model.Pesanan;
import com.mahasiswa.todolist.model.Produk;
import com.mahasiswa.todolist.model.StatusPesanan;
import com.mahasiswa.todolist.repository.KategoriRepository;
import com.mahasiswa.todolist.repository.PelangganRepository;
import com.mahasiswa.todolist.repository.ProdukRepository;
import com.mahasiswa.todolist.service.LaporanService;
import com.mahasiswa.todolist.service.PesananService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test modul Toko Mahasiswa: halaman, ORM, dan aturan bisnis pesanan.
 * Tiap test berjalan dalam transaksi yang di-rollback, sehingga data seeder tidak terganggu.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class TokoMahasiswaTests {

    @Autowired private MockMvc mockMvc;
    @Autowired private PesananService pesananService;
    @Autowired private LaporanService laporanService;
    @Autowired private ProdukRepository produkRepository;
    @Autowired private KategoriRepository kategoriRepository;
    @Autowired private PelangganRepository pelangganRepository;

    private Produk produk;
    private Pelanggan pelanggan;

    @BeforeEach
    void siapkanData() {
        Kategori kategori = kategoriRepository.save(new Kategori("Kategori Test"));
        produk = produkRepository.save(new Produk("Produk Test", "desc", new BigDecimal("10000"), 10, kategori));
        pelanggan = pelangganRepository.save(new Pelanggan("Pelanggan Test", null, "0800", "Alamat"));
    }

    // ---------- Halaman ----------

    @Test
    void halamanTokoDapatDiakses() throws Exception {
        mockMvc.perform(get("/toko")).andExpect(status().isOk()).andExpect(view().name("toko/dashboard"))
                .andExpect(model().attributeExists("ringkasan", "produkTerlaris", "stokMenipis", "pesananTerbaru"));
        mockMvc.perform(get("/produk")).andExpect(status().isOk()).andExpect(view().name("produk/index"));
        mockMvc.perform(get("/produk/tambah")).andExpect(status().isOk()).andExpect(view().name("produk/form"));
        mockMvc.perform(get("/pelanggan")).andExpect(status().isOk()).andExpect(view().name("pelanggan/index"));
        mockMvc.perform(get("/pelanggan/tambah")).andExpect(status().isOk()).andExpect(view().name("pelanggan/form"));
        mockMvc.perform(get("/pesanan")).andExpect(status().isOk()).andExpect(view().name("pesanan/index"));
        mockMvc.perform(get("/pesanan?status=SELESAI")).andExpect(status().isOk());
        mockMvc.perform(get("/pesanan/baru")).andExpect(status().isOk()).andExpect(view().name("pesanan/form"));
    }

    @Test
    void halamanDetailPesananDapatDiakses() throws Exception {
        Pesanan p = pesananService.buatPesanan(pelanggan.getId(), List.of(produk.getId()), List.of(1), null);
        mockMvc.perform(get("/pesanan/" + p.getId()))
                .andExpect(status().isOk())
                .andExpect(view().name("pesanan/detail"));
    }

    @Test
    void simpanProdukTanpaNamaGagalValidasi() throws Exception {
        mockMvc.perform(post("/produk/simpan")
                        .param("nama", "")
                        .param("harga", "1000")
                        .param("stok", "1")
                        .param("kategoriId", String.valueOf(produk.getKategori().getId())))
                .andExpect(status().isOk())
                .andExpect(view().name("produk/form"))
                .andExpect(model().attributeHasFieldErrors("produk", "nama"));
    }

    @Test
    void pesananStokKurangDialihkanDenganPesanGalat() throws Exception {
        mockMvc.perform(post("/pesanan/simpan")
                        .param("pelangganId", String.valueOf(pelanggan.getId()))
                        .param("produkId", String.valueOf(produk.getId()))
                        .param("jumlah", "999"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/pesanan/baru"))
                .andExpect(flash().attributeExists("galat"));
    }

    // ---------- Aturan bisnis ----------

    @Test
    void buatPesananMengurangiStokDanMenghitungTotal() {
        Pesanan p = pesananService.buatPesanan(pelanggan.getId(), List.of(produk.getId()), List.of(3), "catatan");

        assertEquals(7, produkRepository.findById(produk.getId()).orElseThrow().getStok());
        assertEquals(0, new BigDecimal("30000").compareTo(p.getTotalHarga()));
        assertEquals(StatusPesanan.MENUNGGU_PEMBAYARAN, p.getStatus());
        assertTrue(p.getNomorPesanan().startsWith("INV-"));
    }

    @Test
    void barisProdukSamaDigabung() {
        Pesanan p = pesananService.buatPesanan(pelanggan.getId(),
                List.of(produk.getId(), produk.getId()), List.of(2, 3), null);
        assertEquals(1, p.getItems().size());
        assertEquals(5, p.getItems().get(0).getJumlah());
    }

    @Test
    void stokTidakCukupDitolak() {
        BisnisException e = assertThrows(BisnisException.class, () ->
                pesananService.buatPesanan(pelanggan.getId(), List.of(produk.getId()), List.of(11), null));
        assertTrue(e.getMessage().contains("Stok"));
        assertEquals(10, produkRepository.findById(produk.getId()).orElseThrow().getStok());
    }

    @Test
    void pesananTanpaProdukDitolak() {
        assertThrows(BisnisException.class, () ->
                pesananService.buatPesanan(pelanggan.getId(), java.util.Arrays.asList((Long) null), List.of(1), null));
    }

    @Test
    void pembatalanMengembalikanStok() {
        Pesanan p = pesananService.buatPesanan(pelanggan.getId(), List.of(produk.getId()), List.of(4), null);
        assertEquals(6, produkRepository.findById(produk.getId()).orElseThrow().getStok());

        pesananService.ubahStatus(p.getId(), StatusPesanan.DIBATALKAN);

        assertEquals(10, produkRepository.findById(produk.getId()).orElseThrow().getStok());
    }

    @Test
    void alurStatusTidakBolehLompat() {
        Pesanan p = pesananService.buatPesanan(pelanggan.getId(), List.of(produk.getId()), List.of(1), null);
        assertThrows(BisnisException.class, () -> pesananService.ubahStatus(p.getId(), StatusPesanan.SELESAI));

        pesananService.ubahStatus(p.getId(), StatusPesanan.DIBAYAR);
        pesananService.ubahStatus(p.getId(), StatusPesanan.DIKIRIM);
        pesananService.ubahStatus(p.getId(), StatusPesanan.SELESAI);
        assertThrows(BisnisException.class, () -> pesananService.ubahStatus(p.getId(), StatusPesanan.DIBATALKAN));
    }

    @Test
    void laporanMenghitungHanyaPesananTerbayar() {
        BigDecimal sebelum = laporanService.getRingkasan().getTotalPendapatan();

        Pesanan belumBayar = pesananService.buatPesanan(pelanggan.getId(), List.of(produk.getId()), List.of(1), null);
        assertEquals(0, sebelum.compareTo(laporanService.getRingkasan().getTotalPendapatan()));

        pesananService.ubahStatus(belumBayar.getId(), StatusPesanan.DIBAYAR);
        BigDecimal sesudah = laporanService.getRingkasan().getTotalPendapatan();
        assertEquals(0, sebelum.add(new BigDecimal("10000")).compareTo(sesudah));
        assertNotNull(laporanService.getProdukTerlaris(5));
    }
}
