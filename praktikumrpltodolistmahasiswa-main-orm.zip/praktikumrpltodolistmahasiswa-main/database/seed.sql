-- ============================================================
-- Data contoh (OPSIONAL). Jalankan SETELAH schema.sql dan hanya
-- pada database kosong:  mysql -u root -p < database/seed.sql
--
-- Jika Anda lebih suka, biarkan aplikasi mengisi data contoh sendiri
-- (DataSeeder, app.seed.enabled=true). Seeder otomatis dilewati bila
-- tabel mata_kuliah / kategori sudah berisi data.
-- ============================================================
USE db_todolist_mahasiswa;

-- ---------- Akademik ----------
INSERT INTO mata_kuliah (kode, nama, sks) VALUES
 ('TI301','Kecerdasan Buatan',3),
 ('TI302','Jaringan Komputer',3),
 ('TI303','Basis Data Lanjut',3),
 ('TI304','Pemrograman Web',3),
 ('TI305','Etika Profesi TI',2),
 ('TI306','Interaksi Manusia dan Komputer',3),
 ('TI307','Rekayasa Perangkat Lunak',3),
 ('TI308','Sistem Operasi',3);

INSERT INTO tugas (nama_tugas, mata_kuliah_id, deskripsi, deadline, prioritas, status) VALUES
 ('Makalah Penerapan Neural Network pada Citra Medis', (SELECT id FROM mata_kuliah WHERE kode='TI301'),
  'Membuat makalah ilmiah minimal 10 halaman beserta referensi IEEE terbaru.', DATE_ADD(CURDATE(), INTERVAL 3 DAY), 'Tinggi', 'Sedang Dikerjakan'),
 ('Praktikum Routing OSPF & VLAN Modul 4', (SELECT id FROM mata_kuliah WHERE kode='TI302'),
  'Konfigurasi topologi jaringan pada Cisco Packet Tracer dan kumpulkan file .pkt beserta laporan.', DATE_ADD(CURDATE(), INTERVAL 7 DAY), 'Sedang', 'Belum Dikerjakan'),
 ('Normalisasi Database Toko Online ke 3NF & BCNF', (SELECT id FROM mata_kuliah WHERE kode='TI303'),
  'Menganalisis skema tabel relasional unnormalized dan membuat diagram ERD relasi baru.', DATE_SUB(CURDATE(), INTERVAL 2 DAY), 'Tinggi', 'Belum Dikerjakan'),
 ('Implementasi RESTful API Produk dengan Spring Boot', (SELECT id FROM mata_kuliah WHERE kode='TI304'),
  'Membuat endpoint CRUD produk dengan validasi input dan exception handler.', DATE_ADD(CURDATE(), INTERVAL 10 DAY), 'Tinggi', 'Sedang Dikerjakan'),
 ('Analisis Kasus Pelanggaran Hak Cipta Perangkat Lunak', (SELECT id FROM mata_kuliah WHERE kode='TI305'),
  'Review studi kasus pelanggaran lisensi open source vs proprietary.', DATE_SUB(CURDATE(), INTERVAL 5 DAY), 'Rendah', 'Selesai'),
 ('Desain UI/UX Wireframe Dashboard Mobile', (SELECT id FROM mata_kuliah WHERE kode='TI306'),
  'Membuat prototype high-fidelity di Figma untuk aplikasi pemantau aktivitas harian.', DATE_SUB(CURDATE(), INTERVAL 1 DAY), 'Sedang', 'Selesai'),
 ('Laporan Praktikum ORM dengan Hibernate (Pertemuan 4)', (SELECT id FROM mata_kuliah WHERE kode='TI307'),
  'Implementasi entity, repository, dan relasi antar tabel menggunakan Spring Data JPA.', DATE_ADD(CURDATE(), INTERVAL 5 DAY), 'Tinggi', 'Sedang Dikerjakan');

-- ---------- Toko ----------
INSERT INTO kategori (nama) VALUES
 ('Alat Tulis & Perlengkapan Kuliah'), ('Template & Materi Digital'), ('Aksesori Mahasiswa');

-- Stok sudah mencerminkan transaksi contoh di bawah
INSERT INTO produk (nama, deskripsi, harga, stok, aktif, kategori_id, created_at) VALUES
 ('Buku Catatan A5 Hardcover','Buku catatan 100 halaman, kertas 80 gsm.',25000,35,b'1',(SELECT id FROM kategori WHERE nama='Alat Tulis & Perlengkapan Kuliah'),NOW(6)),
 ('Pulpen Gel 0.5mm (isi 12)','Tinta hitam, cepat kering.',30000,29,b'1',(SELECT id FROM kategori WHERE nama='Alat Tulis & Perlengkapan Kuliah'),NOW(6)),
 ('Set Highlighter Pastel (6 warna)','Cocok untuk menandai materi kuliah.',35000,2,b'1',(SELECT id FROM kategori WHERE nama='Alat Tulis & Perlengkapan Kuliah'),NOW(6)),
 ('Template Laporan Praktikum (Word)','Format rapi: cover, daftar isi, bab, daftar pustaka.',15000,998,b'1',(SELECT id FROM kategori WHERE nama='Template & Materi Digital'),NOW(6)),
 ('Template CV & Portofolio Fresh Graduate','Siap edit di Canva dan Word.',20000,998,b'1',(SELECT id FROM kategori WHERE nama='Template & Materi Digital'),NOW(6)),
 ('Tote Bag Kanvas Anak Teknik','Kanvas tebal dengan sablon desain eksklusif.',55000,19,b'1',(SELECT id FROM kategori WHERE nama='Aksesori Mahasiswa'),NOW(6)),
 ('Lanyard + ID Card Holder','Lanyard 2 cm, holder transparan.',12000,4,b'1',(SELECT id FROM kategori WHERE nama='Aksesori Mahasiswa'),NOW(6)),
 ('Botol Minum 750ml','BPA free, bisa dipakai membawa air panas.',65000,14,b'1',(SELECT id FROM kategori WHERE nama='Aksesori Mahasiswa'),NOW(6));

INSERT INTO pelanggan (nama, email, no_hp, alamat, created_at) VALUES
 ('Budi Santoso','budi@mail.com','081234567801','Jl. Melati No. 5, Jakarta',NOW(6)),
 ('Siti Rahma','siti@mail.com','081234567802','Kos Mawar, Jl. Kampus Raya 12, Depok',NOW(6)),
 ('Andi Pratama','andi@mail.com','081234567803','Jl. Kenanga No. 21, Bekasi',NOW(6)),
 ('Dewi Lestari',NULL,'081234567804','Asrama Putri Blok C, Tangerang',NOW(6));

INSERT INTO pesanan (nomor_pesanan, pelanggan_id, tanggal_pesanan, status, catatan, total_harga) VALUES
 (CONCAT('INV-',DATE_FORMAT(NOW(),'%Y%m%d'),'-90001'),(SELECT id FROM pelanggan WHERE nama='Budi Santoso'),NOW(6),'SELESAI','Kirim sore hari',80000),
 (CONCAT('INV-',DATE_FORMAT(NOW(),'%Y%m%d'),'-90002'),(SELECT id FROM pelanggan WHERE nama='Siti Rahma'),NOW(6),'DIBAYAR',NULL,145000),
 (CONCAT('INV-',DATE_FORMAT(NOW(),'%Y%m%d'),'-90003'),(SELECT id FROM pelanggan WHERE nama='Andi Pratama'),NOW(6),'DIKIRIM','COD di kampus',100000),
 (CONCAT('INV-',DATE_FORMAT(NOW(),'%Y%m%d'),'-90004'),(SELECT id FROM pelanggan WHERE nama='Siti Rahma'),NOW(6),'MENUNGGU_PEMBAYARAN',NULL,20000),
 (CONCAT('INV-',DATE_FORMAT(NOW(),'%Y%m%d'),'-90005'),(SELECT id FROM pelanggan WHERE nama='Budi Santoso'),NOW(6),'DIBATALKAN','Batal, salah pilih',24000);

INSERT INTO item_pesanan (pesanan_id, produk_id, jumlah, harga_satuan) VALUES
 ((SELECT id FROM pesanan WHERE nomor_pesanan LIKE '%-90001'),(SELECT id FROM produk WHERE nama LIKE 'Buku Catatan%'),2,25000),
 ((SELECT id FROM pesanan WHERE nomor_pesanan LIKE '%-90001'),(SELECT id FROM produk WHERE nama LIKE 'Pulpen Gel%'),1,30000),
 ((SELECT id FROM pesanan WHERE nomor_pesanan LIKE '%-90002'),(SELECT id FROM produk WHERE nama LIKE 'Template Laporan%'),1,15000),
 ((SELECT id FROM pesanan WHERE nomor_pesanan LIKE '%-90002'),(SELECT id FROM produk WHERE nama LIKE 'Tote Bag%'),1,55000),
 ((SELECT id FROM pesanan WHERE nomor_pesanan LIKE '%-90002'),(SELECT id FROM produk WHERE nama LIKE 'Buku Catatan%'),3,25000),
 ((SELECT id FROM pesanan WHERE nomor_pesanan LIKE '%-90003'),(SELECT id FROM produk WHERE nama LIKE 'Botol Minum%'),1,65000),
 ((SELECT id FROM pesanan WHERE nomor_pesanan LIKE '%-90003'),(SELECT id FROM produk WHERE nama LIKE 'Set Highlighter%'),1,35000),
 ((SELECT id FROM pesanan WHERE nomor_pesanan LIKE '%-90004'),(SELECT id FROM produk WHERE nama LIKE 'Template CV%'),1,20000),
 ((SELECT id FROM pesanan WHERE nomor_pesanan LIKE '%-90005'),(SELECT id FROM produk WHERE nama LIKE 'Lanyard%'),2,12000);
