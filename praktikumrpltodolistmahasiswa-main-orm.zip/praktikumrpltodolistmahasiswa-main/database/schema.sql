-- ============================================================
-- Skema database: To-Do List Mahasiswa + Toko Mahasiswa
-- DBMS : MySQL 8.x / MariaDB 10.x
-- Cara : mysql -u root -p < database/schema.sql
--
-- Catatan: skema ini SAMA dengan hasil pemetaan ORM (entity JPA).
-- Aplikasi dengan spring.jpa.hibernate.ddl-auto=update juga akan
-- membuat tabel-tabel ini otomatis, jadi menjalankan file ini
-- bersifat opsional (berguna untuk dokumentasi / setup manual).
-- ============================================================

CREATE DATABASE IF NOT EXISTS db_todolist_mahasiswa
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_todolist_mahasiswa;

-- ------------------------------------------------------------
-- MODUL AKADEMIK
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mata_kuliah (
    id    BIGINT       NOT NULL AUTO_INCREMENT,
    kode  VARCHAR(20)  NOT NULL,
    nama  VARCHAR(100) NOT NULL,
    sks   INT          NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_mata_kuliah_kode (kode)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tugas (
    id             BIGINT        NOT NULL AUTO_INCREMENT,
    nama_tugas     VARCHAR(150)  NOT NULL,
    mata_kuliah_id BIGINT        NULL,
    deskripsi      VARCHAR(1000) NULL,
    deadline       DATE          NOT NULL,
    prioritas      VARCHAR(20)   NOT NULL,   -- Tinggi | Sedang | Rendah
    status         VARCHAR(30)   NOT NULL,   -- Belum Dikerjakan | Sedang Dikerjakan | Selesai
    PRIMARY KEY (id),
    KEY idx_tugas_status (status),
    KEY idx_tugas_deadline (deadline),
    CONSTRAINT fk_tugas_mata_kuliah FOREIGN KEY (mata_kuliah_id) REFERENCES mata_kuliah (id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- MODUL TOKO MAHASISWA (PENJUALAN)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS kategori (
    id    BIGINT      NOT NULL AUTO_INCREMENT,
    nama  VARCHAR(80) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_kategori_nama (nama)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS produk (
    id           BIGINT         NOT NULL AUTO_INCREMENT,
    nama         VARCHAR(120)   NOT NULL,
    deskripsi    VARCHAR(500)   NULL,
    harga        DECIMAL(12,2)  NOT NULL,
    stok         INT            NOT NULL DEFAULT 0,
    aktif        BIT(1)         NOT NULL DEFAULT b'1',
    kategori_id  BIGINT         NULL,
    created_at   DATETIME(6)    NOT NULL,
    PRIMARY KEY (id),
    KEY idx_produk_kategori (kategori_id),
    CONSTRAINT fk_produk_kategori FOREIGN KEY (kategori_id) REFERENCES kategori (id),
    CONSTRAINT ck_produk_harga CHECK (harga >= 0),
    CONSTRAINT ck_produk_stok  CHECK (stok >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pelanggan (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    nama        VARCHAR(100) NOT NULL,
    email       VARCHAR(100) NULL,
    no_hp       VARCHAR(20)  NULL,
    alamat      VARCHAR(255) NULL,
    created_at  DATETIME(6)  NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pesanan (
    id               BIGINT        NOT NULL AUTO_INCREMENT,
    nomor_pesanan    VARCHAR(40)   NOT NULL,
    pelanggan_id     BIGINT        NOT NULL,
    tanggal_pesanan  DATETIME(6)   NOT NULL,
    status           ENUM('MENUNGGU_PEMBAYARAN','DIBAYAR','DIKIRIM','SELESAI','DIBATALKAN') NOT NULL,
    catatan          VARCHAR(255)  NULL,
    total_harga      DECIMAL(14,2) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_pesanan_nomor (nomor_pesanan),
    KEY idx_pesanan_pelanggan (pelanggan_id),
    KEY idx_pesanan_status (status),
    CONSTRAINT fk_pesanan_pelanggan FOREIGN KEY (pelanggan_id) REFERENCES pelanggan (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS item_pesanan (
    id            BIGINT        NOT NULL AUTO_INCREMENT,
    pesanan_id    BIGINT        NOT NULL,
    produk_id     BIGINT        NOT NULL,
    jumlah        INT           NOT NULL,
    harga_satuan  DECIMAL(12,2) NOT NULL,   -- harga saat transaksi (snapshot)
    PRIMARY KEY (id),
    KEY idx_item_pesanan (pesanan_id),
    KEY idx_item_produk (produk_id),
    CONSTRAINT fk_item_pesanan FOREIGN KEY (pesanan_id) REFERENCES pesanan (id) ON DELETE CASCADE,
    CONSTRAINT fk_item_produk  FOREIGN KEY (produk_id)  REFERENCES produk (id),
    CONSTRAINT ck_item_jumlah  CHECK (jumlah > 0)
) ENGINE=InnoDB;
