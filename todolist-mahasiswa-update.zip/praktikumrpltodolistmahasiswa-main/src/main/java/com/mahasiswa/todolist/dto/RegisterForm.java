package com.mahasiswa.todolist.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Data isian form pendaftaran akun. */
public class RegisterForm {

    @NotBlank(message = "Nama lengkap wajib diisi")
    @Size(max = 100, message = "Nama maksimal 100 karakter")
    private String namaLengkap;

    @NotBlank(message = "Username wajib diisi")
    @Size(min = 3, max = 50, message = "Username 3-50 karakter")
    @Pattern(regexp = "^[A-Za-z0-9_.]*$", message = "Username hanya boleh huruf, angka, titik, dan underscore")
    private String username;

    @NotBlank(message = "Password wajib diisi")
    @Size(min = 6, max = 72, message = "Password 6-72 karakter")
    private String password;

    @NotBlank(message = "Konfirmasi password wajib diisi")
    private String konfirmasiPassword;

    public String getNamaLengkap() { return namaLengkap; }
    public void setNamaLengkap(String namaLengkap) { this.namaLengkap = namaLengkap; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getKonfirmasiPassword() { return konfirmasiPassword; }
    public void setKonfirmasiPassword(String konfirmasiPassword) { this.konfirmasiPassword = konfirmasiPassword; }
}
