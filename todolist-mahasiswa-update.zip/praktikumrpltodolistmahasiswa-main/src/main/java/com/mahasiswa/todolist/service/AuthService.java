package com.mahasiswa.todolist.service;

import com.mahasiswa.todolist.auth.PasswordHasher;
import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.Pengguna;
import com.mahasiswa.todolist.repository.PenggunaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Locale;
import java.util.Optional;

@Service
public class AuthService {

    private final PenggunaRepository penggunaRepository;
    private final PasswordHasher passwordHasher;

    public AuthService(PenggunaRepository penggunaRepository, PasswordHasher passwordHasher) {
        this.penggunaRepository = penggunaRepository;
        this.passwordHasher = passwordHasher;
    }

    @Transactional
    public Pengguna daftar(String namaLengkap, String username, String password) {
        String uname = normalisasi(username);
        if (penggunaRepository.existsByUsername(uname)) {
            throw new BisnisException("Username sudah dipakai, pilih username lain.");
        }
        return penggunaRepository.save(new Pengguna(namaLengkap.trim(), uname, passwordHasher.hash(password)));
    }

    /** @return pengguna jika username & password benar, kosong jika salah. */
    @Transactional(readOnly = true)
    public Optional<Pengguna> login(String username, String password) {
        if (username == null || password == null) {
            return Optional.empty();
        }
        return penggunaRepository.findByUsername(normalisasi(username))
                .filter(p -> passwordHasher.cocok(password, p.getPassword()));
    }

    public boolean usernameTerpakai(String username) {
        return penggunaRepository.existsByUsername(normalisasi(username));
    }

    private String normalisasi(String username) {
        return username == null ? "" : username.trim().toLowerCase(Locale.ROOT);
    }
}
