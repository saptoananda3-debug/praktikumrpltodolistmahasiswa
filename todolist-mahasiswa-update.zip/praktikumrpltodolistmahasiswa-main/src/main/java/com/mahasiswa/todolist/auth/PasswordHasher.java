package com.mahasiswa.todolist.auth;

import org.springframework.stereotype.Component;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Hash password dengan PBKDF2-HMAC-SHA256 + salt acak (bawaan JDK, tanpa library tambahan).
 * Format tersimpan: iterasi:salt(base64):hash(base64)
 */
@Component
public class PasswordHasher {

    private static final int ITERASI = 120_000;
    private static final int PANJANG_SALT = 16;
    private static final int PANJANG_HASH_BIT = 256;
    private static final SecureRandom RANDOM = new SecureRandom();

    public String hash(String passwordAsli) {
        byte[] salt = new byte[PANJANG_SALT];
        RANDOM.nextBytes(salt);
        byte[] hash = pbkdf2(passwordAsli, salt, ITERASI);
        return ITERASI + ":" + Base64.getEncoder().encodeToString(salt)
                + ":" + Base64.getEncoder().encodeToString(hash);
    }

    public boolean cocok(String passwordAsli, String tersimpan) {
        if (passwordAsli == null || tersimpan == null) {
            return false;
        }
        String[] bagian = tersimpan.split(":");
        if (bagian.length != 3) {
            return false;
        }
        try {
            int iterasi = Integer.parseInt(bagian[0]);
            byte[] salt = Base64.getDecoder().decode(bagian[1]);
            byte[] diharapkan = Base64.getDecoder().decode(bagian[2]);
            byte[] hasil = pbkdf2(passwordAsli, salt, iterasi);
            return MessageDigest.isEqual(diharapkan, hasil);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private byte[] pbkdf2(String password, byte[] salt, int iterasi) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterasi, PANJANG_HASH_BIT);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Gagal menghitung hash password", e);
        }
    }
}
