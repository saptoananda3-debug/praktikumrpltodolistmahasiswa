package com.mahasiswa.todolist.auth;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.servlet.HandlerInterceptor;

/** Mengarahkan ke /login bila pengguna belum login (tidak ada penggunaId di session). */
public class AuthInterceptor implements HandlerInterceptor {

    public static final String SESSION_ID = "penggunaId";
    public static final String SESSION_NAMA = "namaPengguna";
    public static final String SESSION_USERNAME = "usernamePengguna";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute(SESSION_ID) != null) {
            return true;
        }
        response.sendRedirect(request.getContextPath() + "/login");
        return false;
    }
}
