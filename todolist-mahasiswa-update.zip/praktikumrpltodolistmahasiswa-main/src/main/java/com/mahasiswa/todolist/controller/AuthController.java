package com.mahasiswa.todolist.controller;

import com.mahasiswa.todolist.auth.AuthInterceptor;
import com.mahasiswa.todolist.dto.RegisterForm;
import com.mahasiswa.todolist.exception.BisnisException;
import com.mahasiswa.todolist.model.Pengguna;
import com.mahasiswa.todolist.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

/** Login, register, dan logout. */
@Controller
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping("/login")
    public String formLogin(HttpSession session) {
        if (session.getAttribute(AuthInterceptor.SESSION_ID) != null) {
            return "redirect:/";
        }
        return "auth/login";
    }

    @PostMapping("/login")
    public String prosesLogin(@RequestParam String username,
                              @RequestParam String password,
                              HttpServletRequest request) {
        Optional<Pengguna> pengguna = authService.login(username, password);
        if (pengguna.isEmpty()) {
            return "redirect:/login?error";
        }
        HttpSession session = request.getSession();
        request.changeSessionId(); // cegah session fixation
        session.setAttribute(AuthInterceptor.SESSION_ID, pengguna.get().getId());
        session.setAttribute(AuthInterceptor.SESSION_NAMA, pengguna.get().getNamaLengkap());
        session.setAttribute(AuthInterceptor.SESSION_USERNAME, pengguna.get().getUsername());
        return "redirect:/";
    }

    @GetMapping("/register")
    public String formRegister(Model model) {
        model.addAttribute("registerForm", new RegisterForm());
        return "auth/register";
    }

    @PostMapping("/register")
    public String prosesRegister(@Valid @ModelAttribute("registerForm") RegisterForm form,
                                 BindingResult binding) {
        if (!binding.hasFieldErrors("konfirmasiPassword") && !binding.hasFieldErrors("password")
                && !form.getPassword().equals(form.getKonfirmasiPassword())) {
            binding.rejectValue("konfirmasiPassword", "tidakSama", "Konfirmasi password tidak sama");
        }
        if (binding.hasErrors()) {
            return "auth/register";
        }
        try {
            authService.daftar(form.getNamaLengkap(), form.getUsername(), form.getPassword());
        } catch (BisnisException e) {
            binding.rejectValue("username", "terpakai", e.getMessage());
            return "auth/register";
        }
        return "redirect:/login?registered";
    }

    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login?logout";
    }
}
