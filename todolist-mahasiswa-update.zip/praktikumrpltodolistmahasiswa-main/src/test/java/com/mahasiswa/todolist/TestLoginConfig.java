package com.mahasiswa.todolist;

import com.mahasiswa.todolist.auth.AuthInterceptor;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.MockMvcBuilderCustomizer;
import org.springframework.context.annotation.Bean;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

/** Membuat semua request MockMvc dianggap sudah login, agar test halaman lama tidak terpental ke /login. */
@TestConfiguration
class TestLoginConfig {

    @Bean
    MockMvcBuilderCustomizer sudahLogin() {
        return builder -> builder.defaultRequest(
                get("/").sessionAttr(AuthInterceptor.SESSION_ID, 1L)
                        .sessionAttr(AuthInterceptor.SESSION_NAMA, "Tester")
                        .sessionAttr(AuthInterceptor.SESSION_USERNAME, "tester"));
    }
}
