package com.mahasiswa.todolist;

import com.mahasiswa.todolist.model.Pengguna;
import com.mahasiswa.todolist.repository.PenggunaRepository;
import com.mahasiswa.todolist.service.AuthService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** Test fitur login/register. Tanpa TestLoginConfig, jadi request dianggap BELUM login. */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class AuthTests {

    @Autowired private MockMvc mockMvc;
    @Autowired private AuthService authService;
    @Autowired private PenggunaRepository penggunaRepository;

    @Test
    void halamanTerlindungiMengarahkanKeLogin() throws Exception {
        mockMvc.perform(get("/")).andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/login"));
        mockMvc.perform(get("/tugas")).andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/login"));
    }

    @Test
    void halamanLoginDanRegisterTerbuka() throws Exception {
        mockMvc.perform(get("/login")).andExpect(status().isOk()).andExpect(view().name("auth/login"));
        mockMvc.perform(get("/register")).andExpect(status().isOk()).andExpect(view().name("auth/register"));
    }

    @Test
    void registerMenyimpanKeDatabaseDenganPasswordTerhash() throws Exception {
        mockMvc.perform(post("/register")
                        .param("namaLengkap", "Budi Santoso")
                        .param("username", "Budi")
                        .param("password", "rahasia123")
                        .param("konfirmasiPassword", "rahasia123"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?registered"));

        Pengguna p = penggunaRepository.findByUsername("budi").orElseThrow();
        assertEquals("Budi Santoso", p.getNamaLengkap());
        assertNotEquals("rahasia123", p.getPassword());
        assertTrue(p.getPassword().contains(":"));
    }

    @Test
    void registerDenganPasswordTidakSamaDitolak() throws Exception {
        mockMvc.perform(post("/register")
                        .param("namaLengkap", "Siti")
                        .param("username", "siti")
                        .param("password", "rahasia123")
                        .param("konfirmasiPassword", "berbeda"))
                .andExpect(status().isOk())
                .andExpect(view().name("auth/register"))
                .andExpect(model().attributeHasFieldErrors("registerForm", "konfirmasiPassword"));
        assertFalse(penggunaRepository.existsByUsername("siti"));
    }

    @Test
    void registerUsernameKembarDitolak() throws Exception {
        authService.daftar("Andi", "andi", "rahasia123");
        mockMvc.perform(post("/register")
                        .param("namaLengkap", "Andi Lain")
                        .param("username", "ANDI")
                        .param("password", "rahasia123")
                        .param("konfirmasiPassword", "rahasia123"))
                .andExpect(status().isOk())
                .andExpect(model().attributeHasFieldErrors("registerForm", "username"));
    }

    @Test
    void loginBenarMasukKeDashboardDanLogoutKeluar() throws Exception {
        authService.daftar("Dewi", "dewi", "rahasia123");

        MockHttpSession session = new MockHttpSession();
        mockMvc.perform(post("/login").session(session).param("username", "dewi").param("password", "rahasia123"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/"));

        mockMvc.perform(get("/").session(session)).andExpect(status().isOk()).andExpect(view().name("dashboard"));

        mockMvc.perform(post("/logout").session(session))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?logout"));
    }

    @Test
    void loginSalahDitolak() throws Exception {
        authService.daftar("Rina", "rina", "rahasia123");
        mockMvc.perform(post("/login").param("username", "rina").param("password", "salah"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?error"));
        mockMvc.perform(post("/login").param("username", "tidakada").param("password", "x"))
                .andExpect(redirectedUrl("/login?error"));
    }
}
